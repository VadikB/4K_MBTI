# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: runtime.spec.mjs >> F08 Finish without ASK closes the AS and waits for explicit Next
- Location: tests/browser/runtime.spec.mjs:601:1

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator:  locator('#onboarding-next')
Expected: enabled
Received: disabled
Timeout:  5000ms

Call log:
  - Expect "toBeEnabled" locator('#onboarding-next') with timeout 5000ms
  - waiting for locator('#onboarding-next')
    14 × locator resolved to <button disabled type="button" id="onboarding-next" class="primary-button">Подождите…</button>
       - unexpected value "disabled"

```

```yaml
- main:
  - strong: 4К Ассистент
  - text: Ситуация 1 из 2 Завершено 0 из 2
  - button "Домой"
  - button "Выйти"
  - 'heading "Запуск в пятницу: что именно готово?" [level=3]'
  - text: 59:57
  - paragraph: Ответы сохраняются в текущей Assessment Situation.
  - complementary "Как работать с ситуацией":
    - strong: Как работать с ситуацией
    - list:
      - listitem: Изучите ситуацию и опишите своё решение в поле ответа.
      - listitem: Если для решения не хватает информации, можно задать собеседнику вопрос.
      - listitem: «Отправить» сохраняет сообщение и продолжает диалог. После отправки ответ нельзя изменить.
      - listitem: «Завершить ситуацию» доступно после сохранения хотя бы одного ответа.
  - region "История диалога и материалы ситуации":
    - text: 4К Ассистент
    - 'heading "Запуск в пятницу: что именно готово?" [level=3]'
    - text: "Ситуация Команда готовит запуск сервиса для 40 клиентских организаций в пятницу. В среду на общем статусе стоит «готово 90%». Коммерческий блок уже сообщил клиентам дату. В четверг вечером тестирование обнаружило, что часть организаций не может завершить подключение. У команд разные представления о готовности и о том, когда изменения стали обязательными. Событие На встрече коммерческий руководитель говорит: «Мы обещали пятницу. Остались мелочи». Руководитель тестирования отвечает: «Это нельзя выпускать; вы назвали готовым то, что мы не принимали». Через час нужно передать спонсору согласованную рекомендацию. Ваша роль Вы ведёте проект и координируете выпуск. Можете остановить неподготовленный этап, менять последовательность работ в согласованных границах и организовать ограниченный запуск после проверки готовности. Изменение внешнего обещания и принятие остаточного бизнес-риска утверждает спонсор. Сотрудники смежных команд вам не подчиняются. Участники На встрече присутствуют: Марина, коммерческий руководитель — Защищает обещанную дату и отношения с клиентами; предлагает выпускать доступное. Илья, руководитель разработки — Считает основную функцию завершённой; возражает против полной переработки за ночь. Вера, руководитель тестирования — Не подписывает полный запуск; требует ясной границы готовности. Павел, руководитель поддержки — Должен обеспечить подключения; не получил окончательную инструкцию. Задача Проведите обсуждение и определите, что команда рекомендует делать с запуском и как продолжит работу. Итог должен быть пригоден для передачи спонсору и исполнения командами. Условия До решения спонсора — один рабочий час, не лимит ответа участника. На сегодня осталось 8 часов разработки и 4 часа тестирования. Полное исправление требует 12 часов разработки, затем 6 часов тестирования; параллельное выполнение этого пути невозможно. Ограниченный контур требует 2 и затем 2 часа соответственно. Поддержка может вести не более 6 нестандартных подключений за день. Новых ресурсов сегодня нет."
  - button "К последним сообщениям"
  - textbox "Ваш ответ или вопрос собеседнику":
    - /placeholder: Введите ответ или вопрос собеседнику...
  - button "Пауза"
  - button "Завершить ситуацию"
  - button "Прервать и продолжить позже"
  - button "Отправить"
  - paragraph: Ответы анализируются алгоритмами AI для оценки компетенций
```

# Test source

```ts
  87  | async function login(page,stand,email='participant@example.test',prepare=false,navigate=true,allowDashboard=false){
  88  |  if(!page.acceptanceDialogHandler){page.on('dialog',dialog=>dialog.accept());page.acceptanceDialogHandler=true;}
  89  |  page.on('response',async response=>{try{if(response.url().endsWith('/runtime') && response.ok()){page.acceptanceCycle=(await response.json()).cycle_id;}}catch{/* Navigation may discard diagnostic response bodies. */}});
  90  |  if(navigate) await page.goto(stand.url);
  91  |  await page.locator('#email-input').fill(email);
  92  |  await page.locator('#request-magic-link-button').click();
  93  |  await page.locator('#magic-token-input').fill(stand.state.password);
  94  |  await page.locator('#verify-magic-link-button').click();
  95  |  const continueButton=page.getByRole('button',{name:'Продолжить',exact:true}).filter({visible:true});
  96  |  const confirm=page.getByRole('button',{name:'Подтвердить профиль',exact:true}).filter({visible:true});
  97  |  const onboardingSkip=page.getByRole('button',{name:'Пропустить',exact:true}).filter({visible:true});
  98  |  const assessmentAction=page.locator('#assessment-action-button').filter({visible:true});
  99  |  const welcomeAction=page.locator('#start-first-assessment').filter({visible:true});
  100 |  const dashboard=page.locator('#dashboard-panel').filter({visible:true});
  101 |  const completedDashboardAction=page.getByRole('button',{name:'В личный кабинет',exact:true}).filter({visible:true});
  102 |  let routeReady=continueButton.or(confirm).or(onboardingSkip).or(assessmentAction).or(welcomeAction);
  103 |  if(allowDashboard)routeReady=routeReady.or(dashboard).or(completedDashboardAction);
  104 |  await expect(routeReady.first()).toBeVisible({timeout:15000});
  105 |  await page.waitForTimeout(1000);
  106 |  if(allowDashboard&&await completedDashboardAction.isVisible()){
  107 |    await completedDashboardAction.click();
  108 |    await expect(dashboard).toBeVisible();
  109 |    return;
  110 |  }
  111 |  if(await onboardingSkip.isVisible())await onboardingSkip.click();
  112 |  routeReady=continueButton.or(confirm).or(assessmentAction).or(welcomeAction);
  113 |  if(allowDashboard)routeReady=routeReady.or(dashboard);
  114 |  await expect(routeReady.first()).toBeVisible();
  115 |  if(await continueButton.isVisible())await continueButton.click();
  116 |  if(await assessmentAction.isVisible()||await welcomeAction.isVisible()||(allowDashboard&&await dashboard.isVisible()))return;
  117 |  await expect(confirm).toBeVisible();
  118 |  await expect(confirm).toBeEnabled();
  119 |  if(prepare){
  120 |    const options=await (await page.request.get(stand.url+'/users/assessment/profile/options')).json();
  121 |    expect(options.current_profile).toBeNull();
  122 |    await page.locator('[name="role_profile_version_id"]').selectOption({label:'Менеджер проекта, продукта или процесса · версия 1'});
  123 |    await page.locator('[name="assessment_configuration_id"]').selectOption({label:'E10.2 controlled catalog'});
  124 |    await page.locator('[name="position"]').fill('Эксперт по программам');
  125 |    await page.locator('[name="duties"]').fill('Согласовать план разработки программ');
  126 |    await test.info().attach('profile-confirmation',{body:await page.screenshot({fullPage:true}),contentType:'image/png'});
  127 |  }
  128 |  await confirm.click();
  129 |  await expect(page.locator('#assessment-action-button')).toBeVisible();
  130 | }
  131 | test('Same-domain email outside the exact allowlist is denied',async({page,stand})=>{
  132 |  await page.goto(stand.url);
  133 |  await page.locator('#email-input').fill('outside@example.test');
  134 |  const denied=page.waitForResponse(response=>new URL(response.url()).pathname==='/users/auth/email/request-link');
  135 |  await page.locator('#request-magic-link-button').click();
  136 |  expect((await denied).status()).toBe(403);
  137 |  await expect(page.locator('#auth-email-sent')).toBeVisible();
  138 |  await expect(page.locator('#auth-email-sent')).toContainText('Доступ пока не открыт');
  139 |  await expect(page.locator('#auth-token-form')).toBeHidden();
  140 | });
  141 | test('Organization invitation keeps context and cannot admit a member of another organization',async({page,stand})=>{
  142 |  const invitation=`browser-invitation-${stand.state.run_id}`;
  143 |  await page.goto(`${stand.url}/?invite=${encodeURIComponent(invitation)}`);
  144 |  await expect(page.locator('#organization-invitation-context')).toContainText('Синтетическая организация E10.2');
  145 |  await expect(page.locator('#organization-invitation-context')).toContainText('Техническое приглашение');
  146 |  await page.reload();
  147 |  await expect(page.locator('#organization-invitation-context')).toContainText('Синтетическая организация E10.2');
  148 |  await page.locator('#email-input').fill('member-b@example.test');
  149 |  const denied=page.waitForResponse(response=>new URL(response.url()).pathname==='/users/auth/email/request-link');
  150 |  await page.locator('#request-magic-link-button').click();
  151 |  expect((await denied).status()).toBe(403);
  152 |  await expect(page.locator('#auth-email-sent')).toBeVisible();
  153 |  await expect(page.locator('#auth-email-sent')).toContainText('Доступ пока не открыт');
  154 |  await expect(page.locator('#auth-token-form')).toBeHidden();
  155 | });
  156 | async function start(page,expected='готовности'){
  157 |  const entrySelector='#dashboard-panel:not(.hidden) #assessment-action-button, #ai-welcome-panel:not(.hidden) #start-first-assessment';
  158 |  await expect.poll(()=>page.locator(entrySelector).count()).toBe(1);
  159 |  await page.evaluate(selector=>document.querySelector(selector)?.click(),entrySelector);
  160 |  await expect.poll(async()=>await page.locator('#onboarding-panel').isVisible() || await page.locator('#prechat-panel').isVisible()).toBe(true);
  161 |  if(await page.locator('#onboarding-panel').isVisible()){
  162 |   await completeAcquaintance(page);
  163 |   if(!await page.locator('#interview-panel').isVisible()){
  164 |    await expect.poll(()=>page.locator(entrySelector).count()).toBe(1);
  165 |    await page.evaluate(selector=>document.querySelector(selector)?.click(),entrySelector);
  166 |   }
  167 |  }
  168 |  if(await page.locator('#prechat-panel').isVisible())await page.locator('#prechat-start-button').click();
  169 |  await expect(page.locator('#interview-textarea')).toBeEnabled({timeout:15000});
  170 |  await expect(page.locator('#interview-messages')).toContainText(expected);
  171 |  await test.info().attach('interview-start',{body:await page.screenshot({fullPage:true}),contentType:'image/png'});
  172 | }
  173 | async function completeAcquaintance(page,{expectBlocked=false}={}){
  174 |  const panel=page.locator('#onboarding-panel');
  175 |  const answers=[
  176 |   'Синтетические задачи: анализировать материалы и согласовывать рабочие решения.',
  177 |   'Синтетические решения: проверять условия и выбирать обоснованный следующий шаг.',
  178 |   'Синтетические ограничения: сроки, зависимости и взаимодействие с коллегами.',
  179 |  ];
  180 |  let answerIndex=0;
  181 |  for(let step=0;step<16 && await panel.isVisible();step+=1){
  182 |   if(expectBlocked && await page.locator('#onboarding-title').textContent()==='Старт оценки пока недоступен')return;
  183 |   const input=panel.locator('.onboarding-answer');
  184 |   if(await input.isEnabled())await input.fill(answers[answerIndex++]||`Синтетический ответ ${answerIndex}.`);
  185 |   const next=page.locator('#onboarding-next');
  186 |   const marker=`${await panel.getAttribute('data-step')}|${await page.locator('#onboarding-title').textContent()}`;
> 187 |   await expect(next).toBeEnabled();
      |                      ^ Error: expect(locator).toBeEnabled() failed
  188 |   const startsAssessment=(await next.textContent())==='Приступить к оценке';
  189 |   const committedStart=startsAssessment?page.waitForResponse(response=>
  190 |    response.request().method()==='POST' && new URL(response.url()).pathname==='/users/assessment/cycles/start',
  191 |    {timeout:30000}):null;
  192 |   await next.click();
  193 |   if(committedStart)expect((await committedStart).ok()).toBeTruthy();
  194 |   await expect.poll(async()=>{
  195 |    if(!await panel.isVisible())return true;
  196 |    return `${await panel.getAttribute('data-step')}|${await page.locator('#onboarding-title').textContent()}`!==marker;
  197 |   },{timeout:5000}).toBe(true);
  198 |  }
  199 |  await expect(panel).toBeHidden();
  200 | }
  201 | test('Unapproved LIMITED is blocked by the real server and UI without a component substitution',async({page,stand},info)=>{
  202 |  await login(page,stand);
  203 |  await page.locator('#dashboard-panel:not(.hidden) #assessment-action-button, #ai-welcome-panel:not(.hidden) #start-first-assessment').click();
  204 |  await expect(page.locator('#onboarding-panel')).toBeVisible();
  205 |  await completeAcquaintance(page,{expectBlocked:true});
  206 |  await expect(page.locator('#onboarding-title')).toHaveText('Старт оценки пока недоступен');
  207 |  await expect(page.getByRole('button',{name:'Приступить к оценке',exact:true})).toHaveCount(0);
  208 |  const uid=await page.evaluate(()=>JSON.parse(localStorage.getItem('agent4k.pendingUser')).id);
  209 |  const model=await (await page.request.get(`${stand.url}/users/${uid}/acquaintance`)).json();
  210 |  const prepared=model.prepared_plan;
  211 |  expect(prepared.plan.status).toBe('LIMITED');
  212 |  expect(prepared.start_readiness.can_start).toBe(false);
  213 |  expect(prepared.start_readiness.reasons).toContain('PILOT_PLAN_PLANNED_TARGET_GAP');
  214 |  const denied=await page.request.post(`${stand.url}/users/assessment/cycles/start`,{
  215 |   data:{idempotency_key:randomUUID(),cycle_id:prepared.cycle_id,selected_skills:['K1','K2','K3','K4']}});
  216 |  expect(denied.status()).toBe(409);
  217 |  expect((await denied.json()).detail).toContain('M7_START_NOT_ADMITTED:PILOT_PLAN_PLANNED_TARGET_GAP');
  218 |  const statusResponse=await page.request.get(`${stand.url}/users/assessment/m7/cycles/${prepared.cycle_id}`);
  219 |  expect(statusResponse.ok()).toBe(true);
  220 |  const status=await statusResponse.json();
  221 |  expect(status.collection_status).toBe('prepared');
  222 |  expect(status.calendar_deadline).toBeNull();
  223 |  await expect(page.locator('#interview-panel')).toBeHidden();
  224 |  await info.attach('real-limited-denial',{body:JSON.stringify({start_readiness:prepared.start_readiness,
  225 |   http_start_status:denied.status(),response:await denied.json(),cycle_status:status,
  226 |   component_substitution:false}),contentType:'application/json'});
  227 | });
  228 | async function startIndependentCycle(page,stand,expected='готовности'){
  229 |  const response=await page.request.post(`${stand.url}/users/assessment/cycles/start`,{
  230 |   data:{idempotency_key:randomUUID(),selected_skills:['K1','K2','K3','K4']},
  231 |  });
  232 |  expect(response.ok()).toBeTruthy();
  233 |  const payload=await response.json();
  234 |  const cycle=payload.runtime?.cycle_id||payload.plan?.cycle_id;
  235 |  expect(cycle).toBeTruthy();page.acceptanceCycle=cycle;
  236 |  await page.goto(`${stand.url}/?screen=interview&cycle_id=${encodeURIComponent(cycle)}`);
  237 |  await expect(page.locator('#interview-textarea')).toBeEnabled({timeout:15000});
  238 |  await expect(page.locator('#interview-messages')).toContainText(expected);
  239 | }
  240 | async function openCompletedReport(page,expectedCycles,cycleId=null){
  241 |  await expect(page.locator('#dashboard-panel')).toBeVisible();
  242 |  await expect(page.locator('#completed-assessments .participant-assessment-card')).toHaveCount(expectedCycles);
  243 |  const card=cycleId
  244 |   ? page.locator(`#completed-assessments .participant-assessment-card [data-cycle-id="${cycleId}"]`).locator('..')
  245 |   : page.locator('#completed-assessments .participant-assessment-card').first();
  246 |  await card.locator('.participant-assessment-action').click();
  247 |  await expect(page.locator('#m8-report-state')).toContainText('Результат готов');
  248 | }
  249 | async function answer(page,text=fixture.answer){
  250 |  const cycle=new URL(page.url()).searchParams.get('cycle_id') || page.acceptanceCycle;
  251 |  expect(cycle).toBeTruthy();
  252 |  await page.locator('#interview-textarea').fill(text);
  253 |  const receipt=page.waitForResponse(response=>response.request().method()==='POST'
  254 |   && /^\/users\/assessment\/(m5\/situations\/[^/]+\/turns|m7\/clarifications\/[^/]+\/answers)$/.test(new URL(response.url()).pathname));
  255 |  await page.locator('#interview-submit-button').click();
  256 |  expect((await receipt).ok()).toBeTruthy();
  257 |  await expect.poll(async()=>{
  258 |   const response=await page.request.get(`${new URL(page.url()).origin}/users/assessment/cycles/${cycle}/runtime`);
  259 |   if(!response.ok())return false;
  260 |   const snapshot=await response.json();
  261 |   return snapshot.trace?.turns?.some(turn=>turn.speaker_type==='assessee' && turn.content_text===text) || false;
  262 |  },{timeout:30000}).toBe(true);
  263 |  await expect(page.locator('#interview-error')).toBeHidden();
  264 |  await expect(page.locator('#interview-messages .own')).toContainText([text]);
  265 | }
  266 | async function report(page,stand,info){
  267 |  const nextCase=page.getByRole('button',{name:'Приступить к следующей ситуации'});
  268 |  try{
  269 |   await nextCase.waitFor({state:'visible',timeout:3000});
  270 |   const cycle=new URL(page.url()).searchParams.get('cycle_id');
  271 |   const closed=await page.request.post(`${stand.url}/users/assessment/m7/cycles/${cycle}/completion`,{
  272 |    data:{action:'complete',reason:'browser_fixture_plan_finished',idempotency_key:randomUUID()},
  273 |   });
  274 |   expect(closed.ok()).toBeTruthy();await page.reload();
  275 |  }catch(_error){}
  276 |  await expect.poll(async()=>page.evaluate(async()=>{
  277 |   const user=JSON.parse(localStorage.getItem('agent4k.pendingUser')||'null');
  278 |   if(!user?.id)return 'missing_owner';
  279 |   const response=await fetch(`/users/${user.id}/journey-state`,{credentials:'same-origin'});
  280 |   if(!response.ok)return `http_${response.status}`;
  281 |   return (await response.json()).report_status;
  282 |  }),{timeout:70000}).toBe('ready');
  283 |  const readyCycle=new URL(page.url()).searchParams.get('cycle_id') || page.acceptanceCycle;
  284 |  expect(readyCycle).toBeTruthy();
  285 |  await page.goto(`${stand.url}/?screen=processing&cycle_id=${encodeURIComponent(readyCycle)}`);
  286 |  await expect(page.locator('#processing-outcome-title')).toHaveText('Ваш результат готов',{timeout:70000});
  287 |  await page.getByRole('button',{name:'Посмотреть результат'}).click();
```