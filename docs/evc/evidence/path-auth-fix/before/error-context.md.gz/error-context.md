# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth-recovery.spec.mjs >> AUTH-DIAG-01 delayed cleanup retains error and fails closed
- Location: tests/browser/auth-recovery.spec.mjs:102:3

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('#auth-error')
Expected substring: "Сессия входа не сохранилась"
Received string:    ""
Timeout: 5000ms

Call log:
  - Expect "toContainText" locator('#auth-error') with timeout 5000ms
  - waiting for locator('#auth-error')
    14 × locator resolved to <p hidden="" class="error" id="auth-error"></p>
       - unexpected value ""

```

```yaml
- main:
  - text: 4К Ассистент
  - heading "С возвращением" [level=1]
  - paragraph: Введите пароль для old-person@example.test.
  - text: Рабочий email
  - textbox "Рабочий email":
    - /placeholder: name@company.ru
  - button "Продолжить"
  - text: Политика конфиденциальности Согласие на обработку персональных данных Версия 2.0.68 © 2026 LIDUM
```

# Test source

```ts
  17  | if (chatFile.length !== 1) throw new Error('Exactly one current built chat entry required');
  18  | const chatUrl = `${base}/web/dist/${chatFile[0]}`;
  19  | let server;
  20  | test.beforeAll(async () => {
  21  |   server = http.createServer(async (request, response) => {
  22  |     try {
  23  |       const pathname = new URL(request.url, base).pathname;
  24  |       const filename = path.join(root, pathname === '/' ? 'web/index.html' : pathname);
  25  |       response.setHeader('Content-Type', path.extname(filename) === '.js' ? 'application/javascript'
  26  |         : path.extname(filename) === '.html' ? 'text/html' : 'text/css');
  27  |       response.end(await fs.readFile(filename));
  28  |     } catch { response.statusCode = 404; response.end('missing'); }
  29  |   });
  30  |   await new Promise((resolve) => server.listen(18766, '127.0.0.1', resolve));
  31  | });
  32  | test.afterAll(async () => new Promise((resolve) => server.close(resolve)));
  33  | 
  34  | const json = (route, body, status = 200) => route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(body) });
  35  | const missingSession = 'Сессия входа не сохранилась';
  36  | 
  37  | async function routes(page) {
  38  |   const counts = { journey401: 0, logout: 0 };
  39  |   await page.route('**/users/**', (route) => {
  40  |     const pathname = new URL(route.request().url()).pathname;
  41  |     if (pathname === '/users/version') return json(route, { version: 'synthetic-auth-regression' });
  42  |     if (pathname === '/users/session/restore') return json(route, { authenticated: false });
  43  |     if (pathname === '/users/auth/email/request-link') return json(route, {
  44  |       email: route.request().postDataJSON().email, auth_mode: 'password', message: 'Введите пароль.',
  45  |     });
  46  |     if (pathname === '/users/auth/email/password-login') {
  47  |       const email = route.request().postDataJSON().email;
  48  |       return json(route, { exists: true, user: { id: email.startsWith('new-') ? 9 : 8, email, full_name: 'Synthetic' },
  49  |         is_admin: false, dashboard: {}, agent: { session_id: 'synthetic-profile', stage: 'profile' } });
  50  |     }
  51  |     if (pathname === '/users/8/journey-state') {
  52  |       counts.journey401 += 1;
  53  |       return json(route, { detail: 'Session not found' }, 401);
  54  |     }
  55  |     if (pathname === '/users/9/journey-state') return json(route, {
  56  |       next_action: 'wait_for_acquaintance_data', acquaintance: { readiness: { status: 'waiting_for_assignment' } },
  57  |     });
  58  |     if (pathname === '/users/session/logout') { counts.logout += 1; return json(route, {}); }
  59  |     return json(route, {}, 404);
  60  |   });
  61  |   return counts;
  62  | }
  63  | 
  64  | async function login(page, email = 'old-person@example.test') {
  65  |   await page.locator('#email-input').fill(email);
  66  |   await page.locator('#request-magic-link-button').click();
  67  |   await expect(page.locator('#magic-token-input')).toBeVisible();
  68  |   await page.locator('#magic-token-input').fill('synthetic-password');
  69  |   await page.locator('#verify-magic-link-button').click();
  70  | }
  71  | 
  72  | async function holdChat(page) {
  73  |   let release;
  74  |   const gate = new Promise((resolve) => { release = resolve; });
  75  |   let requests = 0;
  76  |   await page.route('**/web/dist/chat-*.js', async (route) => {
  77  |     requests += 1;
  78  |     await gate;
  79  |     await route.continue();
  80  |   });
  81  |   return { release, requests: () => requests };
  82  | }
  83  | 
  84  | async function finishChat(page) {
  85  |   // Await the SAME real module, then the next rendering turn: all import/recovery
  86  |   // microtasks have completed. No sleep, DOM mutation or replacement product hook.
  87  |   await page.evaluate(async (url) => {
  88  |     await import(url);
  89  |     await new Promise((resolve) => requestAnimationFrame(resolve));
  90  |   }, chatUrl);
  91  | }
  92  | 
  93  | async function assertClosed(page, { sharedStorage = false } = {}) {
  94  |   await expect(page.locator('#auth-panel')).toBeVisible();
  95  |   for (const id of ['dashboard-panel', 'interview-panel', 'admin-panel', 'profile-panel']) {
  96  |     await expect(page.locator(`#${id}`)).toBeHidden();
  97  |   }
  98  |   if (!sharedStorage) expect(await page.evaluate(() => localStorage.getItem('agent4k.pendingUser'))).toBeNull();
  99  | }
  100 | 
  101 | for (const timing of ['delayed', 'eager']) {
  102 |   test(`AUTH-DIAG-01 ${timing} cleanup retains error and fails closed`, async ({ page }, testInfo) => {
  103 |     testInfo.annotations.push({ type: 'synthetic_http', description: 'No real auth/DB/provider; real built UI and cleanup.' });
  104 |     const counts = await routes(page);
  105 |     const held = timing === 'delayed' ? await holdChat(page) : null;
  106 |     try {
  107 |       await page.goto(base);
  108 |       if (!held) await finishChat(page);
  109 |       await login(page);
  110 |       await expect(page.locator('#auth-error')).toContainText(missingSession);
  111 |       await assertClosed(page);
  112 |       if (held) {
  113 |         expect(held.requests()).toBe(1);
  114 |         held.release();
  115 |       }
  116 |       await finishChat(page);
> 117 |       await expect(page.locator('#auth-error')).toContainText(missingSession);
      |                                                 ^ Error: expect(locator).toContainText(expected) failed
  118 |       await expect(page.locator('#auth-error')).toBeVisible();
  119 |       await expect(page.locator('#auth-status')).toBeHidden();
  120 |       await assertClosed(page);
  121 |       expect(counts).toEqual({ journey401: 1, logout: 0 });
  122 |       await page.screenshot({ path: testInfo.outputPath('after-cleanup.png') });
  123 |       await testInfo.attach('recovery-observation', { body: JSON.stringify({ timing, ...counts,
  124 |         error: await page.locator('#auth-error').textContent(), cleanup_module_settled: true,
  125 |         scope: 'synthetic_http_real_built_ui', historical_causality: 'NOT_ESTABLISHED' }), contentType: 'application/json' });
  126 |     } finally { held?.release(); }
  127 |   });
  128 | }
  129 | 
  130 | test('AUTH-DIAG-01 late cleanup cannot erase a newer account in the same tab', async ({ page }) => {
  131 |   const counts = await routes(page);
  132 |   const held = await holdChat(page);
  133 |   try {
  134 |     await page.goto(base);
  135 |     await login(page);
  136 |     await expect(page.locator('#auth-error')).toContainText(missingSession);
  137 |     expect(held.requests()).toBe(1);
  138 |     await login(page, 'new-person@example.test');
  139 |     await expect(page.locator('#auth-complete-panel')).toBeVisible();
  140 |     held.release();
  141 |     await finishChat(page);
  142 |     await expect(page.locator('#auth-complete-panel')).toBeVisible();
  143 |     await expect(page.locator('#auth-panel')).toBeHidden();
  144 |     expect(await page.evaluate(() => JSON.parse(localStorage.getItem('agent4k.pendingUser')).id)).toBe(9);
  145 |     expect(counts.logout).toBe(0);
  146 |   } finally { held.release(); }
  147 | });
  148 | 
  149 | test('AUTH-DIAG-01 another tab changes generation while cleanup is pending', async ({ page, context }) => {
  150 |   const counts = await routes(page);
  151 |   const held = await holdChat(page);
  152 |   const other = await context.newPage();
  153 |   const otherCounts = await routes(other);
  154 |   try {
  155 |     await page.goto(base);
  156 |     await login(page);
  157 |     await expect(page.locator('#auth-error')).toContainText(missingSession);
  158 |     expect(held.requests()).toBe(1);
  159 |     await other.goto(base);
  160 |     await login(other, 'new-person@example.test');
  161 |     await expect(other.locator('#auth-complete-panel')).toBeVisible();
  162 |     // BroadcastChannel invokes real resetStaleUserState in the original tab.
  163 |     await expect(page.locator('#auth-error')).toBeHidden();
  164 |     held.release();
  165 |     await finishChat(page);
  166 |     await assertClosed(page, { sharedStorage: true });
  167 |     await expect(page.locator('#auth-error')).toBeHidden();
  168 |     await expect(other.locator('#auth-complete-panel')).toBeVisible();
  169 |     expect(counts.logout + otherCounts.logout).toBe(0);
  170 |   } finally { held.release(); await other.close(); }
  171 | });
  172 | 
```