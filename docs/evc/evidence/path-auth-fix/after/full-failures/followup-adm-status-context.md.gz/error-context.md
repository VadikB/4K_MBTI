# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth-r03.spec.mjs >> ADM-STATUS-01 keeps superadmin participant cards readable on narrow viewports
- Location: tests/browser/auth-r03.spec.mjs:1312:1

# Error details

```
Test timeout of 150000ms exceeded.
```

```
Error: locator.fill: Test timeout of 150000ms exceeded.
Call log:
  - waiting for locator('#email-input')
    - locator resolved to <input required="" name="email" type="email" id="email-input" placeholder="name@company.ru" autocomplete="username email" aria-describedby="auth-error"/>
    - fill("admin@example.test")
  - attempting fill action
    - waiting for element to be visible, enabled and editable

```

# Test source

```ts
  654 |     if (pathname === '/users/admin/organizations/3/assessment-program' && route.request().method() === 'GET') {
  655 |       return fulfillJson(route, { connection: serverConnected ? connection : null });
  656 |     }
  657 |     return fulfillJson(route, {}, 404);
  658 |   });
  659 |   await page.goto(base);
  660 |   await page.locator('#admin-open-organizations-button').click();
  661 |   const form = page.locator('[data-action="connect-assessment-program"]');
  662 |   await form.locator('[name="program_definition_id"]').selectOption('11');
  663 |   await form.getByRole('button', { name: 'Подключить' }).click();
  664 |   await expect(form).toContainText('Подключено: Пилот 4К · 9 кейсов · 1.1');
  665 |   await page.locator('#admin-organizations-back-button').click();
  666 |   await expect(page.locator('#admin-panel')).toBeVisible();
  667 |   await page.locator('#admin-open-organizations-button').click();
  668 |   await expect(page.locator('[data-action="connect-assessment-program"]'))
  669 |     .toContainText('Подключено: Пилот 4К · 9 кейсов · 1.1');
  670 | });
  671 | 
  672 | test('PROGRAM01 R10 does not render the old connection result after logout', async ({ page }) => {
  673 |   const dashboard = { is_superadmin: true, metrics: [], insights: [], activity_series: [], competency_average: [] };
  674 |   const connection = {
  675 |     organization_id: 3, program_definition_id: 11, program_name: 'Пилот 4К · 9 кейсов',
  676 |     program_version: '1.1', assignment_ref: 'pilot-4k-9', roles: [], role_capabilities: [],
  677 |   };
  678 |   let releaseReadback;
  679 |   const delayedReadback = new Promise((resolve) => { releaseReadback = resolve; });
  680 |   await page.route('**/users/**', async (route) => {
  681 |     const pathname = new URL(route.request().url()).pathname;
  682 |     if (pathname === '/users/session/restore') return fulfillJson(route, {
  683 |       authenticated: true, user: adminUser, is_admin: true, admin_dashboard: dashboard,
  684 |     });
  685 |     if (pathname === '/users/version') return fulfillJson(route, { version: 'r10-test' });
  686 |     if (pathname === '/users/admin/dashboard') return fulfillJson(route, dashboard);
  687 |     if (pathname === '/users/session/logout') return fulfillJson(route, { ok: true });
  688 |     if (pathname === '/users/admin/organizations' && route.request().method() === 'GET') return fulfillJson(route, {
  689 |       is_superadmin: true,
  690 |       items: [{ id: 3, code: 'r10-context', name: 'R10 Context', is_active: true,
  691 |         domains: [], admins: [], members_count: 0, reports_count: 0, members: [], assessment_program: null }],
  692 |       assessment_programs: [{ id: 11, name: connection.program_name, version: connection.program_version }],
  693 |     });
  694 |     if (pathname === '/users/admin/organizations/3/questionnaire') return fulfillJson(route, { items: [] });
  695 |     if (pathname === '/users/admin/organizations/3/assessment-program' && route.request().method() === 'PUT') {
  696 |       return fulfillJson(route, { connection });
  697 |     }
  698 |     if (pathname === '/users/admin/organizations/3/assessment-program' && route.request().method() === 'GET') {
  699 |       await delayedReadback;
  700 |       return fulfillJson(route, { connection });
  701 |     }
  702 |     return fulfillJson(route, {}, 404);
  703 |   });
  704 |   await page.goto(base);
  705 |   await page.locator('#admin-open-organizations-button').click();
  706 |   const form = page.locator('[data-action="connect-assessment-program"]');
  707 |   await form.locator('[name="program_definition_id"]').selectOption('11');
  708 |   await form.getByRole('button', { name: 'Подключить' }).click();
  709 |   await page.locator('#admin-organizations-logout-button').click();
  710 |   await expect(page.locator('#auth-panel')).toBeVisible();
  711 |   releaseReadback();
  712 |   await expect(page.locator('#auth-panel')).toBeVisible();
  713 |   await expect(page.locator('#admin-organizations-panel')).toBeHidden();
  714 | });
  715 | const adminOrganization = {
  716 |   id: 3, code: 'r03', name: 'R03 Organization', is_active: true, domains: [], admins: [],
  717 |   members_count: 1, reports_count: 0,
  718 |   members: [{ user_id: 8, email: 'person@example.test', full_name: 'Person', has_password: false,
  719 |     registration_status: 'pending', invitation_id: 1, invitation_status: 'queued',
  720 |     invitation_delivery_status: 'queued', invitation_link_status: 'active' }],
  721 | };
  722 | 
  723 | async function openAdminOrganizations(page, invitationHandler, organization = adminOrganization, questionnaireResponse = null, isSuperadmin = false) {
  724 |   await page.route('**/users/**', (route) => {
  725 |     const pathname = new URL(route.request().url()).pathname;
  726 |     if (pathname === '/users/session/restore') return fulfillJson(route, { authenticated: false });
  727 |     if (pathname === '/users/version') return fulfillJson(route, { version: 'r03-test' });
  728 |     if (pathname === '/users/auth/email/request-link') return fulfillJson(route, { email: adminUser.email, auth_mode: 'password' });
  729 |     if (pathname === '/users/auth/email/password-login') return fulfillJson(route, {
  730 |       exists: true, user: adminUser, is_admin: true,
  731 |       agent: { session_id: 'admin', message: '', stage: 'admin', completed: true },
  732 |       admin_dashboard: { metrics: [], insights: [], activity_series: [], competency_average: [] },
  733 |     });
  734 |     if (pathname === '/users/admin/organizations' && route.request().method() === 'GET') {
  735 |       return fulfillJson(route, { is_superadmin: isSuperadmin, items: [organization] });
  736 |     }
  737 |     if (pathname === '/users/admin/organizations/3/questionnaire') {
  738 |       const fallback = { items: [{ id: 11, assignment_ref: 'competencies_4k',
  739 |         status: 'confirmed', channel: 'product_form', validation_json: {}, briefing: {},
  740 |         readiness: {
  741 |           status: 'incomplete',
  742 |           early: { status: 'ready', message: 'Ранний минимум подтверждён. Участников можно приглашать.' },
  743 |           context: { status: 'ready', message: 'Контекст выбранной оценки подтверждён и закреплён сервером.' },
  744 |           roles: { status: 'incomplete', message: 'Нужно проверить связку профиля и роли: 1.',
  745 |             ready: 0, total: 1, action_view: 'people' },
  746 |           preparation: { status: 'idle', message: 'Активной подготовки сейчас нет.' },
  747 |         } }] };
  748 |       return fulfillJson(route, questionnaireResponse?.body || fallback, questionnaireResponse?.status || 200);
  749 |     }
  750 |     if (pathname === '/users/admin/organizations/3/personal-invitations') return invitationHandler(route);
  751 |     return fulfillJson(route, {}, 404);
  752 |   });
  753 |   await page.goto(base);
> 754 |   await page.locator('#email-input').fill(adminUser.email);
      |                                      ^ Error: locator.fill: Test timeout of 150000ms exceeded.
  755 |   await page.locator('#request-magic-link-button').click();
  756 |   await page.locator('#magic-token-input').fill('legacy-password');
  757 |   await page.locator('#verify-magic-link-button').click();
  758 |   await expect(page.locator('#admin-organizations-panel')).toBeVisible();
  759 |   if (organization.members.length) {
  760 |     await page.locator('input[name="invitation_email"]').first().waitFor();
  761 |   } else {
  762 |     await page.locator('.admin-organizations-empty').waitFor();
  763 |   }
  764 | }
  765 | 
  766 | test('QA19-03 keeps the participant section available with no members', async ({ page }) => {
  767 |   await openAdminOrganizations(page, (route) => fulfillJson(route, { items: [] }), {
  768 |     ...adminOrganization, members_count: 0, members: [],
  769 |   });
  770 |   await expect(page.locator('.admin-organization-member')).toHaveCount(0);
  771 |   await expect(page.locator('.admin-organization-members-section').first()).toBeVisible();
  772 | });
  773 | 
  774 | for (const action of ['card', 'cancel-dialog']) {
  775 |   test(`PATH-START ST-R1 ${action}: local view or refusal is not a pending mutation`, async ({ page }, testInfo) => {
  776 |     const organization = { ...adminOrganization,
  777 |       assessment_program: { program_definition_id: 7, program_name: 'Synthetic PATH program',
  778 |         program_version: '1.0', assignment_ref: 'competencies_4k', roles: [] },
  779 |       members: [{ ...adminOrganization.members[0], assessment_assignments: ['competencies_4k'],
  780 |         assessment_stages: { competencies_4k: { code: 'assigned', assignment_id: 41 } } }] };
  781 |     await openAdminOrganizations(page, (route) => fulfillJson(route, { items: [] }), organization);
  782 |     let mutations = 0;
  783 |     page.on('request', (request) => {
  784 |       if (request.url().includes('/users/admin/organizations/') && request.method() !== 'GET') mutations += 1;
  785 |     });
  786 |     if (action === 'card') {
  787 |       await page.locator('[data-action="open-member-card"]').click();
  788 |       await page.locator('.admin-member-card-dialog').getByRole('button', { name: 'Закрыть', exact: true }).click();
  789 |     } else {
  790 |       await page.locator('.admin-organization-member-menu summary').click();
  791 |       await page.getByRole('menuitem', { name: 'Отменить назначение оценки' }).click();
  792 |       await page.getByRole('dialog', { name: 'Отменить назначение?' })
  793 |         .getByRole('button', { name: 'Оставить назначение', exact: true }).click();
  794 |     }
  795 |     const statuses = await page.locator('[data-operation-status]:visible').allTextContents();
  796 |     await testInfo.attach('local-action-result', { body: JSON.stringify({ action, mutations, statuses }),
  797 |       contentType: 'application/json' });
  798 |     expect(mutations).toBe(0);
  799 |     expect(statuses.join(' ')).not.toContain('Выполняем действие…');
  800 |     await expect(page.locator('#admin-organizations-status')).not.toContainText('Выполняем действие…');
  801 |   });
  802 | }
  803 | 
  804 | test('PATH-START ST-R1: confirmed cancellation has local loading and a terminal error', async ({ page }) => {
  805 |   const organization = { ...adminOrganization,
  806 |     assessment_program: { program_definition_id: 7, program_name: 'Synthetic PATH program',
  807 |       program_version: '1.0', assignment_ref: 'competencies_4k', roles: [] },
  808 |     members: [{ ...adminOrganization.members[0], assessment_assignments: ['competencies_4k'],
  809 |       assessment_stages: { competencies_4k: { code: 'assigned', assignment_id: 41 } } }] };
  810 |   await openAdminOrganizations(page, (route) => fulfillJson(route, { items: [] }), organization);
  811 |   let release;
  812 |   let posts = 0;
  813 |   const delayed = new Promise((resolve) => { release = resolve; });
  814 |   await page.route('**/users/admin/organizations/3/assessment-assignments/41/cancel', async (route) => {
  815 |     posts += 1;
  816 |     await delayed;
  817 |     return fulfillJson(route, { detail: 'synthetic service failure' }, 500);
  818 |   });
  819 |   await page.locator('.admin-organization-member-menu summary').click();
  820 |   await page.getByRole('menuitem', { name: 'Отменить назначение оценки' }).click();
  821 |   await expect(page.locator('#admin-organizations-status')).not.toContainText('Выполняем действие…');
  822 |   expect(posts).toBe(0);
  823 |   try {
  824 |     await page.getByRole('dialog', { name: 'Отменить назначение?' })
  825 |       .getByRole('button', { name: 'Отменить назначение', exact: true }).click();
  826 |     await expect(page.locator('[data-operation-status]')).toContainText('Выполняем действие…');
  827 |     expect(posts).toBe(1);
  828 |   } finally {
  829 |     release();
  830 |   }
  831 |   await expect(page.locator('[data-operation-status]')).toBeVisible();
  832 |   await expect(page.locator('[data-operation-status]')).not.toContainText('Выполняем действие…');
  833 |   await page.locator('.admin-organization-member-menu summary').click();
  834 |   await expect(page.getByRole('menuitem', { name: 'Отменить назначение оценки' })).toBeEnabled();
  835 |   expect(posts).toBe(1);
  836 | });
  837 | 
  838 | test('PATH-START ST-R4: authorized read-only preparation action survives renderer', async ({ page }) => {
  839 |   const organization = { ...adminOrganization,
  840 |     members: [{ ...adminOrganization.members[0], assessment_assignments: ['competencies_4k'],
  841 |       assessment_stages: { competencies_4k: { code: 'preparing', label: 'Идёт подготовка оценки',
  842 |         action: 'check_preparation', assignment_id: 41, operation_id: 'synthetic-current-operation' } } }] };
  843 |   await openAdminOrganizations(page, (route) => fulfillJson(route, { items: [] }), organization);
  844 |   await expect(page.getByRole('button', { name: 'Проверить подготовку', exact: true })).toBeVisible();
  845 |   let mutations = 0;
  846 |   page.on('request', (request) => {
  847 |     if (request.url().includes('/users/admin/organizations/') && request.method() !== 'GET') mutations += 1;
  848 |   });
  849 |   await page.getByRole('button', { name: 'Проверить подготовку', exact: true }).click();
  850 |   await expect(page.locator('#admin-organizations-status')).toContainText('обновлено');
  851 |   expect(mutations).toBe(0);
  852 | });
  853 | 
  854 | for (const width of [1440, 320, 390, 768]) {
```