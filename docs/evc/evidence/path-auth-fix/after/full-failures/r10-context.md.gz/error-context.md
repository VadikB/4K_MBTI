# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth-r03.spec.mjs >> PROGRAM01 R10 restores the exact connected program after reopening the card
- Location: tests/browser/auth-r03.spec.mjs:628:1

# Error details

```
Test timeout of 150000ms exceeded.
```

```
Error: locator.selectOption: Test timeout of 150000ms exceeded.
Call log:
  - waiting for locator('[data-action="connect-assessment-program"]').locator('[name="program_definition_id"]')

```

# Test source

```ts
  562 |           return lostCommandResponse ? route.abort('connectionreset') : fulfillJson(route, { connection });
  563 |         }
  564 |         return fulfillJson(route, { connection: { ...connection, organization_id: 999,
  565 |           program_name: 'Foreign organization pilot' } });
  566 |       }
  567 |       return fulfillJson(route, {}, 404);
  568 |     });
  569 |     await page.goto(base);
  570 |     await page.locator('#admin-open-organizations-button').click();
  571 |     const form = page.locator('[data-action="connect-assessment-program"]');
  572 |     await form.locator('[name="program_definition_id"]').selectOption('11');
  573 |     await form.getByRole('button', { name: 'Подключить' }).click();
  574 |     const status = form.locator('[data-operation-status]');
  575 |     await expect(status).toHaveAttribute('data-tone', 'error');
  576 |     await expect(form).not.toContainText('Foreign organization pilot');
  577 |     await expect(form.getByRole('button', { name: 'Подключить' })).toBeEnabled();
  578 |     await form.getByRole('button', { name: 'Подключить' }).click();
  579 |     await expect.poll(() => operationIds.length).toBe(2);
  580 |     expect(operationIds[1]).toBe(operationIds[0]);
  581 |     await expect(status).toHaveAttribute('data-tone', 'error');
  582 |   });
  583 | }
  584 | 
  585 | test('PROGRAM01 R10 confirms a committed connection after the PUT response is lost', async ({ page }) => {
  586 |   const dashboard = { is_superadmin: true, metrics: [], insights: [], activity_series: [], competency_average: [] };
  587 |   const connection = {
  588 |     organization_id: 3, program_definition_id: 11, program_name: 'Пилот 4К · 9 кейсов',
  589 |     program_version: '1.1', assignment_ref: 'pilot-4k-9', roles: [], role_capabilities: [],
  590 |   };
  591 |   const operationIds = [];
  592 |   let serverConnected = false;
  593 |   await page.route('**/users/**', (route) => {
  594 |     const pathname = new URL(route.request().url()).pathname;
  595 |     if (pathname === '/users/session/restore') return fulfillJson(route, {
  596 |       authenticated: true, user: adminUser, is_admin: true, admin_dashboard: dashboard,
  597 |     });
  598 |     if (pathname === '/users/version') return fulfillJson(route, { version: 'r10-test' });
  599 |     if (pathname === '/users/admin/dashboard') return fulfillJson(route, dashboard);
  600 |     if (pathname === '/users/admin/organizations' && route.request().method() === 'GET') return fulfillJson(route, {
  601 |       is_superadmin: true,
  602 |       items: [{ id: 3, code: 'r10-lost', name: 'R10 Lost Response', is_active: true,
  603 |         domains: [], admins: [], members_count: 0, reports_count: 0, members: [],
  604 |         assessment_program: serverConnected ? connection : null }],
  605 |       assessment_programs: [{ id: 11, name: connection.program_name, version: connection.program_version }],
  606 |     });
  607 |     if (pathname === '/users/admin/organizations/3/questionnaire') return fulfillJson(route, { items: [] });
  608 |     if (pathname === '/users/admin/organizations/3/assessment-program' && route.request().method() === 'PUT') {
  609 |       operationIds.push(route.request().postDataJSON().operation_id);
  610 |       serverConnected = true;
  611 |       return route.abort('connectionreset');
  612 |     }
  613 |     if (pathname === '/users/admin/organizations/3/assessment-program' && route.request().method() === 'GET') {
  614 |       return fulfillJson(route, { connection });
  615 |     }
  616 |     return fulfillJson(route, {}, 404);
  617 |   });
  618 |   await page.goto(base);
  619 |   await page.locator('#admin-open-organizations-button').click();
  620 |   const form = page.locator('[data-action="connect-assessment-program"]');
  621 |   await form.locator('[name="program_definition_id"]').selectOption('11');
  622 |   await form.getByRole('button', { name: 'Подключить' }).click();
  623 |   await expect(form.locator('[data-operation-status]')).toContainText('подтверждено повторным чтением');
  624 |   await expect(form).toContainText('Подключено: Пилот 4К · 9 кейсов · 1.1');
  625 |   expect(operationIds).toHaveLength(1);
  626 | });
  627 | 
  628 | test('PROGRAM01 R10 restores the exact connected program after reopening the card', async ({ page }) => {
  629 |   const dashboard = { is_superadmin: true, metrics: [], insights: [], activity_series: [], competency_average: [] };
  630 |   const connection = {
  631 |     organization_id: 3, program_definition_id: 11, program_name: 'Пилот 4К · 9 кейсов',
  632 |     program_version: '1.1', assignment_ref: 'pilot-4k-9', roles: [], role_capabilities: [],
  633 |   };
  634 |   let serverConnected = false;
  635 |   await page.route('**/users/**', (route) => {
  636 |     const pathname = new URL(route.request().url()).pathname;
  637 |     if (pathname === '/users/session/restore') return fulfillJson(route, {
  638 |       authenticated: true, user: adminUser, is_admin: true, admin_dashboard: dashboard,
  639 |     });
  640 |     if (pathname === '/users/version') return fulfillJson(route, { version: 'r10-test' });
  641 |     if (pathname === '/users/admin/dashboard') return fulfillJson(route, dashboard);
  642 |     if (pathname === '/users/admin/organizations' && route.request().method() === 'GET') return fulfillJson(route, {
  643 |       is_superadmin: true,
  644 |       items: [{ id: 3, code: 'r10-reload', name: 'R10 Reload', is_active: true,
  645 |         domains: [], admins: [], members_count: 0, reports_count: 0, members: [],
  646 |         assessment_program: serverConnected ? connection : null }],
  647 |       assessment_programs: [{ id: 11, name: connection.program_name, version: connection.program_version }],
  648 |     });
  649 |     if (pathname === '/users/admin/organizations/3/questionnaire') return fulfillJson(route, { items: [] });
  650 |     if (pathname === '/users/admin/organizations/3/assessment-program' && route.request().method() === 'PUT') {
  651 |       serverConnected = true;
  652 |       return fulfillJson(route, { connection });
  653 |     }
  654 |     if (pathname === '/users/admin/organizations/3/assessment-program' && route.request().method() === 'GET') {
  655 |       return fulfillJson(route, { connection: serverConnected ? connection : null });
  656 |     }
  657 |     return fulfillJson(route, {}, 404);
  658 |   });
  659 |   await page.goto(base);
  660 |   await page.locator('#admin-open-organizations-button').click();
  661 |   const form = page.locator('[data-action="connect-assessment-program"]');
> 662 |   await form.locator('[name="program_definition_id"]').selectOption('11');
      |                                                        ^ Error: locator.selectOption: Test timeout of 150000ms exceeded.
  663 |   await form.getByRole('button', { name: 'Подключить' }).click();
  664 |   await expect(form).toContainText('Подключено: Пилот 4К · 9 кейсов · 1.1');
  665 |   await page.locator('#admin-organizations-back-button').click();
  666 |   await expect(page.locator('#admin-panel')).toBeVisible();
  667 |   await page.locator('#admin-open-organizations-button').click();
  668 |   await expect(page.locator('[data-action="connect-assessment-program"]'))
  669 |     .toContainText('Подключено: Пилот 4К · 9 кейсов · 1.1');
  670 | });
  671 | 
  672 | test('PROGRAM01 R10 does not render the old connection result after logout', async ({ page }) => {
  673 |   const dashboard = { is_superadmin: true, metrics: [], insights: [], activity_series: [], competency_average: [] };
  674 |   const connection = {
  675 |     organization_id: 3, program_definition_id: 11, program_name: 'Пилот 4К · 9 кейсов',
  676 |     program_version: '1.1', assignment_ref: 'pilot-4k-9', roles: [], role_capabilities: [],
  677 |   };
  678 |   let releaseReadback;
  679 |   const delayedReadback = new Promise((resolve) => { releaseReadback = resolve; });
  680 |   await page.route('**/users/**', async (route) => {
  681 |     const pathname = new URL(route.request().url()).pathname;
  682 |     if (pathname === '/users/session/restore') return fulfillJson(route, {
  683 |       authenticated: true, user: adminUser, is_admin: true, admin_dashboard: dashboard,
  684 |     });
  685 |     if (pathname === '/users/version') return fulfillJson(route, { version: 'r10-test' });
  686 |     if (pathname === '/users/admin/dashboard') return fulfillJson(route, dashboard);
  687 |     if (pathname === '/users/session/logout') return fulfillJson(route, { ok: true });
  688 |     if (pathname === '/users/admin/organizations' && route.request().method() === 'GET') return fulfillJson(route, {
  689 |       is_superadmin: true,
  690 |       items: [{ id: 3, code: 'r10-context', name: 'R10 Context', is_active: true,
  691 |         domains: [], admins: [], members_count: 0, reports_count: 0, members: [], assessment_program: null }],
  692 |       assessment_programs: [{ id: 11, name: connection.program_name, version: connection.program_version }],
  693 |     });
  694 |     if (pathname === '/users/admin/organizations/3/questionnaire') return fulfillJson(route, { items: [] });
  695 |     if (pathname === '/users/admin/organizations/3/assessment-program' && route.request().method() === 'PUT') {
  696 |       return fulfillJson(route, { connection });
  697 |     }
  698 |     if (pathname === '/users/admin/organizations/3/assessment-program' && route.request().method() === 'GET') {
  699 |       await delayedReadback;
  700 |       return fulfillJson(route, { connection });
  701 |     }
  702 |     return fulfillJson(route, {}, 404);
  703 |   });
  704 |   await page.goto(base);
  705 |   await page.locator('#admin-open-organizations-button').click();
  706 |   const form = page.locator('[data-action="connect-assessment-program"]');
  707 |   await form.locator('[name="program_definition_id"]').selectOption('11');
  708 |   await form.getByRole('button', { name: 'Подключить' }).click();
  709 |   await page.locator('#admin-organizations-logout-button').click();
  710 |   await expect(page.locator('#auth-panel')).toBeVisible();
  711 |   releaseReadback();
  712 |   await expect(page.locator('#auth-panel')).toBeVisible();
  713 |   await expect(page.locator('#admin-organizations-panel')).toBeHidden();
  714 | });
  715 | const adminOrganization = {
  716 |   id: 3, code: 'r03', name: 'R03 Organization', is_active: true, domains: [], admins: [],
  717 |   members_count: 1, reports_count: 0,
  718 |   members: [{ user_id: 8, email: 'person@example.test', full_name: 'Person', has_password: false,
  719 |     registration_status: 'pending', invitation_id: 1, invitation_status: 'queued',
  720 |     invitation_delivery_status: 'queued', invitation_link_status: 'active' }],
  721 | };
  722 | 
  723 | async function openAdminOrganizations(page, invitationHandler, organization = adminOrganization, questionnaireResponse = null, isSuperadmin = false) {
  724 |   await page.route('**/users/**', (route) => {
  725 |     const pathname = new URL(route.request().url()).pathname;
  726 |     if (pathname === '/users/session/restore') return fulfillJson(route, { authenticated: false });
  727 |     if (pathname === '/users/version') return fulfillJson(route, { version: 'r03-test' });
  728 |     if (pathname === '/users/auth/email/request-link') return fulfillJson(route, { email: adminUser.email, auth_mode: 'password' });
  729 |     if (pathname === '/users/auth/email/password-login') return fulfillJson(route, {
  730 |       exists: true, user: adminUser, is_admin: true,
  731 |       agent: { session_id: 'admin', message: '', stage: 'admin', completed: true },
  732 |       admin_dashboard: { metrics: [], insights: [], activity_series: [], competency_average: [] },
  733 |     });
  734 |     if (pathname === '/users/admin/organizations' && route.request().method() === 'GET') {
  735 |       return fulfillJson(route, { is_superadmin: isSuperadmin, items: [organization] });
  736 |     }
  737 |     if (pathname === '/users/admin/organizations/3/questionnaire') {
  738 |       const fallback = { items: [{ id: 11, assignment_ref: 'competencies_4k',
  739 |         status: 'confirmed', channel: 'product_form', validation_json: {}, briefing: {},
  740 |         readiness: {
  741 |           status: 'incomplete',
  742 |           early: { status: 'ready', message: 'Ранний минимум подтверждён. Участников можно приглашать.' },
  743 |           context: { status: 'ready', message: 'Контекст выбранной оценки подтверждён и закреплён сервером.' },
  744 |           roles: { status: 'incomplete', message: 'Нужно проверить связку профиля и роли: 1.',
  745 |             ready: 0, total: 1, action_view: 'people' },
  746 |           preparation: { status: 'idle', message: 'Активной подготовки сейчас нет.' },
  747 |         } }] };
  748 |       return fulfillJson(route, questionnaireResponse?.body || fallback, questionnaireResponse?.status || 200);
  749 |     }
  750 |     if (pathname === '/users/admin/organizations/3/personal-invitations') return invitationHandler(route);
  751 |     return fulfillJson(route, {}, 404);
  752 |   });
  753 |   await page.goto(base);
  754 |   await page.locator('#email-input').fill(adminUser.email);
  755 |   await page.locator('#request-magic-link-button').click();
  756 |   await page.locator('#magic-token-input').fill('legacy-password');
  757 |   await page.locator('#verify-magic-link-button').click();
  758 |   await expect(page.locator('#admin-organizations-panel')).toBeVisible();
  759 |   if (organization.members.length) {
  760 |     await page.locator('input[name="invitation_email"]').first().waitFor();
  761 |   } else {
  762 |     await page.locator('.admin-organizations-empty').waitFor();
```