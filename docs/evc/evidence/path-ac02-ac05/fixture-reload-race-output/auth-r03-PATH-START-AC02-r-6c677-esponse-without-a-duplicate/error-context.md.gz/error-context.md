# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth-r03.spec.mjs >> PATH-START AC02 repeats organization creation after service-error response without a duplicate
- Location: tests/browser/auth-r03.spec.mjs:278:3

# Error details

```
Error: locator.fill: Test ended.
Call log:
  - waiting for locator('#admin-organization-name-input')
    - locator resolved to <input type="text" autocomplete="off" placeholder="Например, ACME" id="admin-organization-name-input"/>
    - fill("Owned synthetic AC02")
  - attempting fill action
    2 × waiting for element to be visible, enabled and editable
      - element is not visible
    - retrying fill action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and editable
      - element is not visible
    - retrying fill action
      - waiting 100ms
    74 × waiting for element to be visible, enabled and editable
       - element is not visible
     - retrying fill action
       - waiting 500ms

```

# Test source

```ts
  235 |   await expect(page.locator('#session-restore-retry')).toBeVisible();
  236 |   await expect(page.locator('#email-input')).toBeHidden();
  237 |   await expect(page.locator('.app-footer-release')).toHaveText(`Версия ${appRelease}`);
  238 | });
  239 | 
  240 | test('ADM28 initial HTML has a complete frontend version before JavaScript', async ({ browser }) => {
  241 |   const context = await browser.newContext({ javaScriptEnabled: false });
  242 |   try {
  243 |     const page = await context.newPage();
  244 |     await page.goto(base);
  245 |     await expect(page.locator('#session-restore-panel')).toBeVisible();
  246 |     await expect(page.locator('.app-footer-release')).toHaveText(`Версия ${appRelease}`);
  247 |     await expect(page.locator('#email-input')).toBeHidden();
  248 |   } finally { await context.close(); }
  249 | });
  250 | 
  251 | test('ADM28 invalid JSON leaves a finite unknown outcome and restores confirm controls', async ({ page }) => {
  252 |   const { card, preview } = await adm28Preview(page);
  253 |   await page.route('**/users/admin/organizations/3/questionnaire/201/confirm', (route) =>
  254 |     route.fulfill({ status: 200, contentType: 'application/json', body: '{broken' }));
  255 |   await preview.getByRole('button', { name: 'Подтвердить сведения' }).click();
  256 |   await expect(card).toContainText('Итог подтверждения неизвестен');
  257 |   await expect(preview).not.toContainText('Подтверждаем…');
  258 |   await expect(card.getByRole('button', { name: 'Проверить результат' })).toBeEnabled();
  259 | });
  260 | 
  261 | test('ADM28 superadmin still restores its global dashboard', async ({ page }) => {
  262 |   const dashboard = { is_superadmin: true, metrics: [], insights: [], activity_series: [], competency_average: [] };
  263 |   await page.route('**/users/**', (route) => {
  264 |     const path = new URL(route.request().url()).pathname;
  265 |     if (path === '/users/session/restore') return fulfillJson(route, {
  266 |       authenticated: true, user: adminUser, is_admin: true, admin_dashboard: dashboard,
  267 |     });
  268 |     if (path === '/users/admin/dashboard') return fulfillJson(route, dashboard);
  269 |     return fulfillJson(route, {});
  270 |   });
  271 |   await page.goto(base);
  272 |   await expect(page.locator('#admin-panel')).toBeVisible();
  273 |   await expect(page.locator('#admin-organizations-panel')).toBeHidden();
  274 |   await expect(page.locator('#admin-open-methodology-button')).toBeVisible();
  275 | });
  276 | 
  277 | for (const firstReply of ['confirmed', 'lost', 'service-error']) {
  278 |   test(`PATH-START AC02 repeats organization creation after ${firstReply} response without a duplicate`, async ({ page }, testInfo) => {
  279 |     testInfo.annotations.push({ type: 'synthetic_http', description: 'Stateful HTTP fixture; real entry/dist; no DB/provider.' });
  280 |     const dashboard = { is_superadmin: true, metrics: [], insights: [], activity_series: [], competency_average: [] };
  281 |     const items = [];
  282 |     const posts = [];
  283 |     let releaseCreate;
  284 |     const pendingCreate = new Promise((resolve) => { releaseCreate = resolve; });
  285 |     const listing = () => ({ is_superadmin: true, items, assessment_programs: [] });
  286 |     await page.route('**/users/**', async (route) => {
  287 |       const pathname = new URL(route.request().url()).pathname;
  288 |       if (pathname === '/users/session/restore') return fulfillJson(route, {
  289 |         authenticated: true, user: adminUser, is_admin: true, admin_dashboard: dashboard,
  290 |       });
  291 |       if (pathname === '/users/version') return fulfillJson(route, { version: 'ac02-test' });
  292 |       if (pathname === '/users/admin/dashboard') return fulfillJson(route, dashboard);
  293 |       if (pathname === '/users/admin/organizations') {
  294 |         if (route.request().method() === 'GET') return fulfillJson(route, listing());
  295 |         const payload = route.request().postDataJSON();
  296 |         posts.push(payload);
  297 |         if (posts.length === 1) {
  298 |           await pendingCreate;
  299 |           if (firstReply === 'service-error') return fulfillJson(route, { detail: 'Synthetic create unavailable' }, 503);
  300 |         }
  301 |         if (items.some((item) => item.code === payload.code)) {
  302 |           return fulfillJson(route, { detail: 'Organization with this code already exists' }, 409);
  303 |         }
  304 |         items.push({ ...payload, id: 3, is_active: true, domains: [], admins: [],
  305 |           members_count: 0, reports_count: 0, members: [], assessment_program: null });
  306 |         if (posts.length === 1 && firstReply === 'lost') return route.abort('connectionreset');
  307 |         return fulfillJson(route, listing());
  308 |       }
  309 |       if (pathname === '/users/admin/organizations/3/questionnaire') return fulfillJson(route, { items: [] });
  310 |       return fulfillJson(route, {}, 404);
  311 |     });
  312 |     await page.goto(base);
  313 |     await page.locator('#admin-open-organizations-button').click();
  314 |     const name = page.locator('#admin-organization-name-input');
  315 |     const code = page.locator('#admin-organization-code-input');
  316 |     const button = page.locator('#admin-organization-create-button');
  317 |     const status = page.locator('#admin-organizations-status');
  318 |     await name.fill('Owned synthetic AC02');
  319 |     await code.fill('owned-ac02');
  320 |     await button.click();
  321 |     try {
  322 |       await expect.poll(() => posts.length).toBe(1);
  323 |       await expect(button).toBeDisabled();
  324 |       // A real keyboard repeat while the command is pending must not issue another POST.
  325 |       await name.press('Enter');
  326 |       expect(posts).toHaveLength(1);
  327 |     } finally { releaseCreate(); }
  328 |     await expect(status).toHaveAttribute('data-tone', firstReply === 'confirmed' ? 'success' : 'error');
  329 |     await expect(button).toBeEnabled();
  330 |     await page.reload();
  331 |     if (await page.locator('#admin-open-organizations-button').isVisible()) {
  332 |       await page.locator('#admin-open-organizations-button').click();
  333 |     }
  334 |     await expect(page.locator('[data-organization-id="3"]')).toHaveCount(firstReply === 'service-error' ? 0 : 1);
> 335 |     await name.fill('Owned synthetic AC02');
      |                ^ Error: locator.fill: Test ended.
  336 |     await code.fill('owned-ac02');
  337 |     await button.click();
  338 |     await expect.poll(() => posts.length).toBe(2);
  339 |     await expect(status).toHaveAttribute('data-tone', firstReply === 'service-error' ? 'success' : 'error');
  340 |     if (firstReply !== 'service-error') await expect(status).toContainText('Organization with this code already exists');
  341 |     expect(items).toHaveLength(1);
  342 |     expect(posts[1]).toEqual(posts[0]);
  343 |     await expect(button).toBeEnabled();
  344 |     await page.reload();
  345 |     if (await page.locator('#admin-open-organizations-button').isVisible()) {
  346 |       await page.locator('#admin-open-organizations-button').click();
  347 |     }
  348 |     await expect(page.locator('[data-organization-id="3"]')).toHaveCount(1);
  349 |     await expect(page.locator('[data-organization-id="3"]')).toContainText('Owned synthetic AC02');
  350 |     await page.screenshot({ path: testInfo.outputPath('ac02-result.png') });
  351 |   });
  352 | }
  353 | 
  354 | for (const lostCommandResponse of [false, true]) {
  355 |   for (const readbackFailure of ['deadline', 'http503', 'network', 'invalid-json', 'null', 'foreign-program']) {
  356 |     test(`PATH-START AC05 ${readbackFailure} GET after ${lostCommandResponse ? 'lost' : 'confirmed'} PUT is finite, unknown and safely repeatable`, async ({ page }, testInfo) => {
  357 |       testInfo.annotations.push({ type: 'synthetic_http', description: 'Real entry/dist and unmodified 15s deadline; HTTP faults only, no DB/provider.' });
  358 |       const dashboard = { is_superadmin: true, metrics: [], insights: [], activity_series: [], competency_average: [] };
  359 |       const connection = { organization_id: 3, program_definition_id: 11,
  360 |         program_name: 'Owned AC05 pilot', program_version: 'synthetic-v1', assignment_ref: 'ac05',
  361 |         roles: [], role_capabilities: [] };
  362 |       const organization = { id: 3, code: 'owned-ac05', name: 'Owned AC05 organization',
  363 |         is_active: true, domains: [], admins: [], members_count: 0, reports_count: 0,
  364 |         members: [], assessment_program: null };
  365 |       const operationIds = [];
  366 |       let getCount = 0;
  367 |       let releaseReadback;
  368 |       const stalledReadback = new Promise((resolve) => { releaseReadback = resolve; });
  369 |       await page.route('**/users/**', async (route) => {
  370 |         const pathname = new URL(route.request().url()).pathname;
  371 |         if (pathname === '/users/session/restore') return fulfillJson(route, {
  372 |           authenticated: true, user: adminUser, is_admin: true, admin_dashboard: dashboard,
  373 |         });
  374 |         if (pathname === '/users/version') return fulfillJson(route, { version: 'ac05-test' });
  375 |         if (pathname === '/users/admin/dashboard') return fulfillJson(route, dashboard);
  376 |         if (pathname === '/users/admin/organizations' && route.request().method() === 'GET') {
  377 |           return fulfillJson(route, { is_superadmin: true, items: [organization],
  378 |             assessment_programs: [{ id: 11, name: connection.program_name, version: connection.program_version }] });
  379 |         }
  380 |         if (pathname === '/users/admin/organizations/3/questionnaire') return fulfillJson(route, { items: [] });
  381 |         if (pathname === '/users/admin/organizations/3/assessment-program') {
  382 |           if (route.request().method() === 'PUT') {
  383 |             operationIds.push(route.request().postDataJSON().operation_id);
  384 |             organization.assessment_program = connection; // Fixture models a committed command, even if its response is lost.
  385 |             return lostCommandResponse ? route.abort('connectionreset') : fulfillJson(route, { connection });
  386 |           }
  387 |           getCount += 1;
  388 |           if (getCount > 1) return fulfillJson(route, { connection });
  389 |           if (readbackFailure === 'deadline') { await stalledReadback; return fulfillJson(route, { connection }); }
  390 |           if (readbackFailure === 'http503') return fulfillJson(route, { detail: 'Synthetic readback unavailable' }, 503);
  391 |           if (readbackFailure === 'network') return route.abort('connectionreset');
  392 |           if (readbackFailure === 'invalid-json') return route.fulfill({ status: 200, contentType: 'application/json', body: '{' });
  393 |           if (readbackFailure === 'null') return fulfillJson(route, { connection: null });
  394 |           return fulfillJson(route, { connection: { ...connection, program_definition_id: 999, program_name: 'Foreign program' } });
  395 |         }
  396 |         return fulfillJson(route, {}, 404);
  397 |       });
  398 |       await page.goto(base);
  399 |       await page.locator('#admin-open-organizations-button').click();
  400 |       const form = page.locator('[data-action="connect-assessment-program"]');
  401 |       const button = form.getByRole('button', { name: 'Подключить', exact: true });
  402 |       await form.locator('[name="program_definition_id"]').selectOption('11');
  403 |       await button.click();
  404 |       const status = form.locator('[data-operation-status]');
  405 |       try {
  406 |         await expect(status).toHaveAttribute('data-tone', 'error', { timeout: 22000 });
  407 |         await expect(status).not.toContainText('Выполняем действие');
  408 |         await expect(button).toBeEnabled();
  409 |         await expect(form).not.toContainText('Программа ещё не подключена.');
  410 |         await expect(form).not.toContainText('Foreign program');
  411 |         await page.screenshot({ path: testInfo.outputPath('ac05-unknown.png') });
  412 |       } finally { releaseReadback(); }
  413 |       await button.click();
  414 |       await expect(form.locator('[data-operation-status]')).toHaveAttribute('data-tone', 'success');
  415 |       await expect(form).toContainText('Подключено: Owned AC05 pilot · synthetic-v1');
  416 |       expect(operationIds).toHaveLength(2);
  417 |       expect(operationIds[1]).toBe(operationIds[0]);
  418 |       expect(new Set(operationIds).size).toBe(1);
  419 |       expect(getCount).toBe(2);
  420 |       await page.reload();
  421 |       if (await page.locator('#admin-open-organizations-button').isVisible()) {
  422 |         await page.locator('#admin-open-organizations-button').click();
  423 |       }
  424 |       await expect(form).toContainText('Подключено: Owned AC05 pilot · synthetic-v1');
  425 |     });
  426 |   }
  427 | }
  428 | 
  429 | test('PROGRAM01 R10 finishes exact program connection while questionnaire refresh is pending', async ({ page }) => {
  430 |   const dashboard = { is_superadmin: true, metrics: [], insights: [], activity_series: [], competency_average: [] };
  431 |   const connection = {
  432 |     organization_id: 3, program_definition_id: 11, program_name: 'Пилот 4К · 9 кейсов',
  433 |     program_version: '1.1', assignment_ref: 'pilot-4k-9', roles: [], role_capabilities: [],
  434 |   };
  435 |   const organization = {
```