# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: program-connection-feedback.spec.mjs >> R10-STATUS 503 confirmed survives completion and re-render
- Location: tests/browser/program-connection-feedback.spec.mjs:92:3

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('[data-organization-id="3"] [data-action="connect-assessment-program"]').locator('[data-operation-status]')
Expected substring: "Опубликованная версия программы подключена"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" locator('[data-organization-id="3"] [data-action="connect-assessment-program"]').locator('[data-operation-status]') with timeout 5000ms
  - waiting for locator('[data-organization-id="3"] [data-action="connect-assessment-program"]').locator('[data-operation-status]')

```

```yaml
- main:
  - text: 4К Ассистент
  - navigation "Разделы аккаунта":
    - button "Управление"
  - text: Synthetic admin 18
  - button "К сводке"
  - button "Выйти"
  - paragraph: Управление
  - heading "Организации" [level=2]
  - paragraph: Управление доменами и администраторами организаций.
  - paragraph: Новая организация
  - heading "Создать организацию" [level=3]
  - text: Название
  - textbox "Название":
    - /placeholder: Например, ACME
  - text: Код
  - textbox "Код":
    - /placeholder: acme
  - button "Создать"
  - paragraph: Рабочая область
  - heading "Управление организацией" [level=3]
  - text: Выберите организацию
  - combobox "Выберите организацию":
    - option "Synthetic organization 3 · synthetic-3" [selected]
    - option "Synthetic organization 4 · synthetic-4"
  - heading "Ранее отвязанные аккаунты" [level=3]
  - paragraph: Ранее отвязанных аккаунтов нет.
  - article:
    - paragraph: synthetic-3
    - heading "Synthetic organization 3" [level=3]
    - paragraph: Активна
    - text: 0 участников 0 отчетов
    - button "Подготовить кейсы всем"
    - button "Деактивировать"
    - text: Программа оценки
    - combobox "Программа оценки":
      - option "Выберите опубликованную версию"
      - option "Synthetic pilot 11 · synthetic-1" [selected]
      - option "Synthetic pilot 12 · synthetic-1"
    - button "Подключить"
    - paragraph:
      - text: "Подключено:"
      - strong: Synthetic pilot 11 · synthetic-1
    - paragraph: Профиль
    - heading "Сведения об организации" [level=4]
    - button "Сохранить карточку"
    - text: Название
    - textbox "Название": Synthetic organization 3
    - text: Код
    - textbox "Код": synthetic-3
    - text: Год основания
    - spinbutton "Год основания"
    - text: Численность
    - spinbutton "Численность"
    - text: Отрасль
    - textbox "Отрасль":
      - /placeholder: Например, финтех
    - text: Сайт
    - textbox "Сайт":
      - /placeholder: https://company.ru
    - text: Штаб-квартира
    - textbox "Штаб-квартира":
      - /placeholder: Город, страна
    - text: Прочая существенная информация
    - textbox "Прочая существенная информация":
      - /placeholder: Структура, география, культура и другие важные сведения
    - heading "Домены" [level=4]
    - paragraph: Домены не заданы.
    - textbox "company.ru"
    - button "Добавить"
    - heading "Администраторы" [level=4]
    - paragraph: Администраторы не заданы.
    - textbox "admin@company.ru"
    - button "Добавить"
    - navigation "Разделы управления":
      - button "Организация и участники"
      - button "Данные организации" [pressed]
      - button "Анкета"
    - alert:
      - text: Сервис не смог выполнить операцию. Повторная отправка может быть небезопасна — сначала обновите состояние.
      - button "Повторить"
    - strong: Готовность выбранной оценки «pilot-11» ещё не рассчитана
    - paragraph: Сохраните сведения или загрузите анкету, чтобы увидеть готовность этой оценки.
    - heading "Данные организации и выбранной оценки" [level=4]
    - paragraph: Черновик можно редактировать. Участники увидят новые сведения после подтверждения.
    - region "Выбранная оценка программы":
      - strong: Synthetic pilot 11
      - term: Версия программы
      - definition: synthetic-1
      - term: Роль
      - definition: не выбрана
      - term: Ключ оценки
      - definition:
        - code: pilot-11
    - text: Автор сведений
    - textbox "Автор сведений":
      - /placeholder: Ответственный со стороны заказчика
    - text: Название организации
    - textbox "Название организации"
    - text: Тип организации
    - textbox "Тип организации"
    - text: Сфера деятельности
    - textbox "Сфера деятельности"
    - text: Описание деятельности
    - textbox "Описание деятельности"
    - text: Цель оценки
    - textbox "Цель оценки"
    - text: Использование результатов
    - textbox "Использование результатов"
    - text: Кто увидит результаты
    - textbox "Кто увидит результаты"
    - text: Организатор
    - textbox "Организатор"
    - text: Контакт ответственного
    - textbox "Контакт ответственного"
    - text: Реалистичность кейсов
    - textbox "Реалистичность кейсов"
    - text: Правила использования названия
    - textbox "Правила использования названия"
    - button "Сохранить черновик и предпросмотр"
  - text: Политика конфиденциальности Согласие на обработку персональных данных Версия 2.0.68 © 2026 LIDUM
```

# Test source

```ts
  1   | // Synthetic HTTP only; real entry/dist, no replacement DOM/product methods.
  2   | import { test, expect } from '@playwright/test';
  3   | import fs from 'node:fs/promises';
  4   | import http from 'node:http';
  5   | import path from 'node:path';
  6   | const root = process.cwd();
  7   | const base = 'http://127.0.0.1:18767';
  8   | let server;
  9   | const releases = new Set();
  10  | const gate = () => {
  11  |   let release;
  12  |   const promise = new Promise((resolve) => { release = resolve; });
  13  |   releases.add(release);
  14  |   return { promise, release };
  15  | };
  16  | test.beforeAll(async () => {
  17  |   server = http.createServer(async (request, response) => {
  18  |     try {
  19  |       const file = path.join(root, new URL(request.url, base).pathname === '/' ? 'web/index.html' : new URL(request.url, base).pathname);
  20  |       response.setHeader('Content-Type', { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css',
  21  |         '.svg': 'image/svg+xml', '.woff': 'font/woff' }[path.extname(file)] || 'application/octet-stream');
  22  |       response.end(await fs.readFile(file));
  23  |     } catch { response.statusCode = 404; response.end('missing'); }
  24  |   });
  25  |   await new Promise((resolve) => server.listen(18767, '127.0.0.1', resolve));
  26  | });
  27  | test.afterEach(() => { releases.forEach((release) => release()); releases.clear(); });
  28  | test.afterAll(async () => new Promise((resolve) => server.close(resolve)));
  29  | const json = (route, body, status = 200) => route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(body) });
  30  | const success = 'Опубликованная версия программы подключена';
  31  | const recovery = 'Подключение подтверждено повторным чтением';
  32  | const form = (page) => page.locator('[data-organization-id="3"] [data-action="connect-assessment-program"]');
  33  | const status = (page) => form(page).locator('[data-operation-status]');
  34  | const connection = (org, program) => ({ organization_id: org, program_definition_id: program,
  35  |   program_name: `Synthetic pilot ${program}`, program_version: 'synthetic-1', assignment_ref: `pilot-${program}`, roles: [], role_capabilities: [] });
  36  | 
  37  | async function fixture(page, { questionnaireStatus = 503, lostPut = false } = {}) {
  38  |   const questionnaire = gate();
  39  |   const state = { linked: 0, puts: 0, reads: 0, questionnaires: 0, failNextPut: false, commandGate: null };
  40  |   const dashboard = { is_superadmin: true, metrics: [], insights: [], activity_series: [], competency_average: [] };
  41  |   const user = (id = 18) => ({ id, email: `admin-${id}@example.test`, full_name: `Synthetic admin ${id}` });
  42  |   const auth = (id = 18) => ({ authenticated: true, exists: true, user: user(id), is_admin: true, admin_dashboard: dashboard });
  43  |   const organization = (id) => ({ id, code: `synthetic-${id}`, name: `Synthetic organization ${id}`, is_active: true,
  44  |     domains: [], admins: [], members: [], members_count: 0, reports_count: 0,
  45  |     assessment_program: id === 4 ? connection(4, 11) : state.linked ? connection(3, state.linked) : null });
  46  |   let initialQuestionnaire = true;
  47  |   await page.route('**/users/**', async (route) => {
  48  |     const pathname = new URL(route.request().url()).pathname;
  49  |     if (pathname === '/users/version') return json(route, { version: 'synthetic-r10-feedback' });
  50  |     if (pathname === '/users/session/restore') return json(route, auth());
  51  |     if (pathname === '/users/session/logout') return json(route, { ok: true });
  52  |     if (pathname === '/users/auth/email/request-link') return json(route, { email: user(28).email, auth_mode: 'password' });
  53  |     if (pathname === '/users/auth/email/password-login') return json(route, auth(28));
  54  |     if (pathname === '/users/admin/dashboard') return json(route, dashboard);
  55  |     if (pathname === '/users/admin/organizations') return json(route, { is_superadmin: true,
  56  |       items: [organization(3), organization(4)], assessment_programs: [11, 12].map((id) => ({ id, name: `Synthetic pilot ${id}`, version: 'synthetic-1' })) });
  57  |     if (pathname.endsWith('/questionnaire')) {
  58  |       state.questionnaires += 1;
  59  |       if (pathname.includes('/3/') && initialQuestionnaire) { initialQuestionnaire = false; await questionnaire.promise; }
  60  |       return questionnaireStatus === 200 ? json(route, { items: [] }) : json(route, { detail: 'Synthetic questionnaire unavailable' }, questionnaireStatus);
  61  |     }
  62  |     if (pathname === '/users/admin/organizations/3/assessment-program') {
  63  |       if (route.request().method() === 'PUT') {
  64  |         state.puts += 1;
  65  |         await state.commandGate;
  66  |         if (state.failNextPut) return json(route, { detail: 'Synthetic rejected command' }, 503);
  67  |         state.linked = route.request().postDataJSON().program_definition_id;
  68  |         return lostPut ? route.abort('connectionreset') : json(route, { connection: connection(3, state.linked) });
  69  |       }
  70  |       state.reads += 1;
  71  |       return json(route, { connection: state.linked ? connection(3, state.linked) : null });
  72  |     }
  73  |     return json(route, {}, 404);
  74  |   });
  75  |   await page.goto(base);
  76  |   await expect(page.locator('#admin-open-organizations-button')).toBeVisible();
  77  |   await page.locator('#admin-open-organizations-button').click();
  78  |   await expect(form(page)).toBeVisible();
  79  |   return { state, releaseQuestionnaire: questionnaire.release, message: lostPut ? recovery : success };
  80  | }
  81  | async function connect(page, f) {
  82  |   await form(page).locator('[name="program_definition_id"]').selectOption('11');
  83  |   await form(page).getByRole('button', { name: 'Подключить', exact: true }).click();
  84  |   await expect(status(page)).toContainText(f.message);
  85  | }
  86  | async function rerender(page) {
  87  |   // Non-mutating real UI action triggers the same card renderer. This is also a
  88  |   // deterministic barrier: assertions cannot pass just before a delayed render.
  89  |   await page.locator('[data-organization-id="3"]').getByRole('button', { name: 'Данные организации', exact: true }).click();
  90  | }
  91  | for (const questionnaireStatus of [200, 503]) for (const lostPut of [false, true]) {
  92  |   test(`R10-STATUS ${questionnaireStatus} ${lostPut ? 'lost' : 'confirmed'} survives completion and re-render`, async ({ page }, info) => {
  93  |     info.annotations.push({ type: 'synthetic_http', description: 'Real UI and render; no DB/provider or real program admission.' });
  94  |     const f = await fixture(page, { questionnaireStatus, lostPut });
  95  |     await connect(page, f);
  96  |     expect(f.state.questionnaires).toBeGreaterThanOrEqual(2);
  97  |     f.releaseQuestionnaire();
  98  |     await rerender(page);
> 99  |     await expect(status(page)).toContainText(f.message);
      |                                ^ Error: expect(locator).toContainText(expected) failed
  100 |     await expect(status(page)).toHaveAttribute('data-tone', 'success');
  101 |     await expect(form(page)).toContainText('Подключено: Synthetic pilot 11');
  102 |     expect(f.state.puts).toBe(1); expect(f.state.reads).toBe(1);
  103 |     await page.screenshot({ path: info.outputPath('persistent-outcome.png') });
  104 |   });
  105 | }
  106 | test('R10-STATUS changing program clears the prior outcome without resurrection', async ({ page }) => {
  107 |   const f = await fixture(page); await connect(page, f); f.releaseQuestionnaire();
  108 |   await form(page).locator('[name="program_definition_id"]').selectOption('12');
  109 |   await expect(status(page)).toHaveCount(0);
  110 |   await rerender(page); await expect(status(page)).toHaveCount(0);
  111 |   await form(page).locator('[name="program_definition_id"]').selectOption('11');
  112 |   await rerender(page); await expect(status(page)).toHaveCount(0);
  113 |   expect(f.state.puts).toBe(1);
  114 | });
  115 | test('R10-STATUS a new failed intent cannot revive success and its error survives render', async ({ page }) => {
  116 |   const f = await fixture(page); await connect(page, f); f.releaseQuestionnaire();
  117 |   f.state.failNextPut = true;
  118 |   await form(page).locator('[name="program_definition_id"]').selectOption('12');
  119 |   await form(page).getByRole('button', { name: 'Подключить', exact: true }).click();
  120 |   await expect(status(page)).toContainText('Результат подключения не подтверждён');
  121 |   await rerender(page);
  122 |   await expect(status(page)).toHaveAttribute('data-tone', 'error');
  123 |   await expect(status(page)).not.toContainText(success);
  124 |   expect(f.state.puts).toBe(2);
  125 | });
  126 | test('R10-STATUS same program in another organization never receives the old outcome', async ({ page }) => {
  127 |   const f = await fixture(page); await connect(page, f); f.releaseQuestionnaire();
  128 |   await page.locator('#admin-organization-select').selectOption('4');
  129 |   await expect(page.locator('[data-organization-id="4"]')).toContainText('Подключено: Synthetic pilot 11');
  130 |   await expect(page.locator('[data-organization-id="4"] [data-operation-status]')).toHaveCount(0);
  131 |   await page.locator('#admin-organization-select').selectOption('3');
  132 |   await expect(status(page)).toHaveCount(0);
  133 | });
  134 | test('R10-STATUS logout and another account cannot restore the previous outcome', async ({ page }) => {
  135 |   const f = await fixture(page); await connect(page, f); f.releaseQuestionnaire();
  136 |   await page.locator('#admin-organizations-logout-button').click();
  137 |   await expect(page.locator('#auth-panel')).toBeVisible();
  138 |   await page.locator('#email-input').fill('admin-28@example.test');
  139 |   await page.locator('#request-magic-link-button').click();
  140 |   await page.locator('#magic-token-input').fill('synthetic-password');
  141 |   await page.locator('#verify-magic-link-button').click();
  142 |   await expect(page.locator('#admin-panel')).toBeVisible();
  143 |   await page.locator('#admin-open-organizations-button').click();
  144 |   await expect(page.locator('#admin-organizations-account-name')).toHaveText('Synthetic admin 28');
  145 |   await expect(form(page)).toContainText('Подключено: Synthetic pilot 11');
  146 |   await expect(status(page)).toHaveCount(0);
  147 | });
  148 | test('R10-STATUS a late command cannot restore feedback after program selection changes', async ({ page }) => {
  149 |   const f = await fixture(page); f.releaseQuestionnaire();
  150 |   const held = gate(); f.state.commandGate = held.promise;
  151 |   await form(page).locator('[name="program_definition_id"]').selectOption('11');
  152 |   await form(page).getByRole('button', { name: 'Подключить', exact: true }).click();
  153 |   await expect.poll(() => f.state.puts).toBe(1);
  154 |   await form(page).locator('[name="program_definition_id"]').selectOption('12');
  155 |   held.release();
  156 |   await expect(form(page)).toContainText('Подключено: Synthetic pilot 11');
  157 |   await rerender(page); await expect(status(page)).toHaveCount(0);
  158 |   await form(page).locator('[name="program_definition_id"]').selectOption('11');
  159 |   await rerender(page); await expect(status(page)).toHaveCount(0);
  160 | });
  161 | test('R10-STATUS changed server program invalidates the saved outcome even with an old draft', async ({ page }) => {
  162 |   const f = await fixture(page); await connect(page, f); f.releaseQuestionnaire();
  163 |   f.state.linked = 12;
  164 |   await page.locator('#admin-organizations-back-button').click();
  165 |   await expect(page.locator('#admin-panel')).toBeVisible();
  166 |   await page.locator('#admin-open-organizations-button').click();
  167 |   await expect(form(page)).toContainText('Подключено: Synthetic pilot 12');
  168 |   await expect(status(page)).toHaveCount(0);
  169 | });
  170 | 
```