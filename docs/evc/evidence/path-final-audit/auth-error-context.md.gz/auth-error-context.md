# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth-recovery-race.diagnostic.mjs >> AUTH-DIAG-01: unauthorized cleanup must retain the missing-session error
- Location: tests/browser/auth-recovery-race.diagnostic.mjs:25:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('#auth-error')
Expected substring: "Сессия входа не сохранилась"
Received string:    ""
Timeout: 5000ms

Call log:
  - Expect "toContainText" locator('#auth-error') with timeout 5000ms
  - waiting for locator('#auth-error')
    14 × locator resolved to <p hidden="" class="error" id="auth-error"></p>
       - unexpected value ""

```

```yaml
- main:
  - text: 4К Ассистент
  - heading "С возвращением" [level=1]
  - paragraph: Введите пароль для person@example.test.
  - text: Рабочий email
  - textbox "Рабочий email":
    - /placeholder: name@company.ru
  - button "Продолжить"
  - text: Политика конфиденциальности Согласие на обработку персональных данных Версия 2.0.68 © 2026 LIDUM
```

# Test source

```ts
  1  | // Opt-in negative diagnosis, NOT part of the standard *.spec.mjs acceptance suite.
  2  | // Real HTML/entry/dist; synthetic HTTP only, no DOM/fetch/timer replacement.
  3  | import { test, expect } from '@playwright/test';
  4  | import fs from 'node:fs/promises';
  5  | import http from 'node:http';
  6  | import path from 'node:path';
  7  | 
  8  | const root = process.cwd();
  9  | const base = 'http://127.0.0.1:18765';
  10 | let server;
  11 | test.beforeAll(async () => {
  12 |   server = http.createServer(async (request, response) => {
  13 |     try {
  14 |       const pathname = new URL(request.url, base).pathname;
  15 |       const filename = path.join(root, pathname === '/' ? 'web/index.html' : pathname);
  16 |       response.setHeader('Content-Type', path.extname(filename) === '.js' ? 'application/javascript'
  17 |         : path.extname(filename) === '.html' ? 'text/html' : 'text/css');
  18 |       response.end(await fs.readFile(filename));
  19 |     } catch { response.statusCode = 404; response.end('missing'); }
  20 |   });
  21 |   await new Promise((resolve) => server.listen(18765, '127.0.0.1', resolve));
  22 | });
  23 | test.afterAll(async () => new Promise((resolve) => server.close(resolve)));
  24 | 
  25 | test('AUTH-DIAG-01: unauthorized cleanup must retain the missing-session error', async ({ page }, testInfo) => {
  26 |   testInfo.annotations.push({ type: 'synthetic_http', description: 'Explicitly delayed chat asset; no real auth/provider/DB; not evidence of historical timing.' });
  27 |   let releaseChat;
  28 |   const gate = new Promise((resolve) => { releaseChat = resolve; });
  29 |   let heldChatRequests = 0;
  30 |   let journey401 = 0;
  31 |   await page.route('**/web/dist/chat-*.js', async (route) => {
  32 |     heldChatRequests += 1;
  33 |     await gate;
  34 |     await route.continue();
  35 |   });
  36 |   const json = (route, body, status = 200) => route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(body) });
  37 |   await page.route('**/users/**', (route) => {
  38 |     const pathname = new URL(route.request().url()).pathname;
  39 |     if (pathname === '/users/version') return json(route, { version: '2.0.68' });
  40 |     if (pathname === '/users/session/restore') return json(route, { authenticated: false });
  41 |     if (pathname === '/users/auth/email/request-link') return json(route, { email: 'person@example.test', auth_mode: 'password', message: 'Введите пароль.' });
  42 |     if (pathname === '/users/auth/email/password-login') return json(route, {
  43 |       exists: true, user: { id: 8, email: 'person@example.test', full_name: 'Person' }, is_admin: false,
  44 |       agent: { session_id: 'profile-session', message: '', stage: 'profile', completed: false }, dashboard: {},
  45 |     });
  46 |     if (pathname === '/users/8/journey-state') {
  47 |       journey401 += 1;
  48 |       return json(route, { detail: 'Session not found' }, 401);
  49 |     }
  50 |     return json(route, {}, 404);
  51 |   });
  52 |   try {
  53 |     await page.goto(base);
  54 |     await page.locator('#email-input').fill('person@example.test');
  55 |     await page.locator('#request-magic-link-button').click();
  56 |     await expect(page.locator('#magic-token-input')).toBeVisible();
  57 |     await page.locator('#magic-token-input').fill('synthetic-password');
  58 |     await page.locator('#verify-magic-link-button').click();
  59 |     await expect(page.locator('#auth-error')).toContainText('Сессия входа не сохранилась');
  60 |     expect(journey401).toBe(1);
  61 |     expect(heldChatRequests).toBeGreaterThan(0);
  62 |     const before = await page.locator('#auth-error').textContent();
  63 |     await page.screenshot({ path: testInfo.outputPath('before-delayed-cleanup.png') });
  64 |     releaseChat();
  65 |     await expect.poll(async () => (await page.locator('#auth-error').textContent()) === '', { timeout: 5000 }).toBe(true);
  66 |     const after = await page.locator('#auth-error').textContent();
  67 |     await testInfo.attach('diagnostic-observation', { body: JSON.stringify({
  68 |       scope: 'deterministic_synthetic_transport_reproduction', before, after, journey401, heldChatRequests,
  69 |       expected: 'Missing-session error remains after lazy unauthorized cleanup',
  70 |       actual: 'Error was cleared by the delayed real chat module cleanup',
  71 |       historical_causality: 'NOT_ESTABLISHED', product_changed: false,
  72 |     }, null, 2), contentType: 'application/json' });
  73 |     // The final assertion intentionally exposes the current product defect.
> 74 |     await expect(page.locator('#auth-error')).toContainText('Сессия входа не сохранилась');
     |                                               ^ Error: expect(locator).toContainText(expected) failed
  75 |   } finally { releaseChat(); }
  76 | });
  77 | 
```