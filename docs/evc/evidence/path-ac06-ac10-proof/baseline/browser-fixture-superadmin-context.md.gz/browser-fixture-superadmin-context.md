# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: path-admin-contract.spec.mjs >> AC09 actual HTTP+PostgreSQL: double click, committed lost response, reload and repeat
- Location: tests/browser/path-admin-contract.spec.mjs:8:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator:  locator('#admin-organizations-panel')
Expected: visible
Received: hidden
Timeout:  5000ms

Call log:
  - Expect "toBeVisible" locator('#admin-organizations-panel') with timeout 5000ms
  - waiting for locator('#admin-organizations-panel')
    14 × locator resolved to <section id="admin-organizations-panel" class="panel admin-organizations-panel hidden">…</section>
       - unexpected value "hidden"

```

```yaml
- main:
  - text: 4K Ассистент
  - strong: Синтетический суперадминистратор
  - text: Администратор СС
  - paragraph: Административный раздел
  - heading "Сводный отчет" [level=2]
  - button "Пройти оценивание"
  - button "Организации"
  - button "Регрессионные тесты"
  - button "Управление кейсами"
  - button "Prompt Lab"
  - button "Подробные отчеты"
  - article:
    - text: Пользователи
    - strong: "7"
    - text: +2 с профилем
  - article:
    - text: Процент завершения
    - strong: 0%
    - text: 0 из 0 сессий
  - article:
    - text: Средний индекс
    - strong: 0.0/100
    - text: по завершенным ассессментам
  - article:
    - text: Среднее время прохождения
    - strong: 0 мин
    - text: 0.0 кейса в среднем
  - article:
    - paragraph: Компетенции
    - heading "Средний % по компетенциям" [level=3]
  - paragraph: Инсайты
  - heading "Ключевые выводы" [level=3]
  - article:
    - strong: Пока нет данных для выводов
    - paragraph: Аналитика появится после завершения оценок.
  - paragraph: Динамика
  - heading "Количество завершенных ассессментов за период" [level=3]
  - text: Период
  - combobox "Период":
    - option "7 дней"
    - option "14 дней"
    - option "30 дней" [selected]
    - option "3 месяца"
    - option "6 месяцев"
    - option "12 месяцев"
  - text: Политика конфиденциальности Согласие на обработку персональных данных Версия 2.0.69 © 2026 LIDUM
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | import { spawn, spawnSync } from 'node:child_process';
  3   | import fs from 'node:fs';
  4   | import path from 'node:path';
  5   | import { randomUUID } from 'node:crypto';
  6   | import { capturePathViewports } from './fixtures/path-viewports.mjs';
  7   | 
  8   | test('AC09 actual HTTP+PostgreSQL: double click, committed lost response, reload and repeat', async ({ browser }) => {
  9   |   test.setTimeout(150000);
  10  |   if (!process.env.STAND_ADMIN_URL) throw new Error('Explicit isolated STAND_ADMIN_URL required');
  11  |   const python = process.env.BROWSER_PYTHON || path.join(process.cwd(), '.venv/bin/python');
  12  |   const dir = path.join(process.env.PATH_ADMIN_BROWSER_EVIDENCE || '.test-stand/path-admin-contract', randomUUID());
  13  |   fs.mkdirSync(dir, { recursive: true });
  14  |   const statePath = path.resolve(dir, 'state.json'), base = 'http://127.0.0.1:18872';
  15  |   const cli = (action) => {
  16  |     const result = spawnSync(python, ['scripts/test_stand.py', action, '--state', statePath, '--port', '18872'], { encoding: 'utf8', timeout: 180000 });
  17  |     fs.appendFileSync(path.join(dir, 'stand.log'), result.stdout + result.stderr);
  18  |     if (result.status !== 0) throw new Error('stand ' + action + ' failed; see stand.log');
  19  |   };
  20  |   const inputs = (action) => {
  21  |     const result = spawnSync(python, ['tests/path_admin_browser_inputs.py', action, '--state', statePath], { encoding: 'utf8', timeout: 60000 });
  22  |     if (result.status !== 0) throw new Error(result.stderr);
  23  |     return JSON.parse(result.stdout.trim().split('\n').at(-1));
  24  |   };
  25  |   let server, context;
  26  |   const events = [];
  27  |   cli('create');
  28  |   try {
  29  |     cli('bootstrap');
  30  |     cli('seed');
  31  |     const prepared = inputs('prepare');
  32  |     const fd = fs.openSync(path.join(dir, 'server.log'), 'a');
  33  |     server = spawn(python, ['scripts/test_stand.py', 'serve', '--state', statePath], { stdio: ['ignore', fd, fd] });
  34  |     fs.closeSync(fd);
  35  |     await expect.poll(async () => { try { return (await fetch(base + '/health/ready')).status; } catch { return 0; } }, { timeout: 30000 }).toBe(200);
  36  |     context = await browser.newContext();
  37  |     await context.addCookies([{ name: prepared.cookie_name, value: prepared.super_session, url: base }]);
  38  |     const superPage = await context.newPage();
  39  |     await superPage.goto(base);
> 40  |     await expect(superPage.locator('#admin-organizations-panel')).toBeVisible();
      |                                                                   ^ Error: expect(locator).toBeVisible() failed
  41  |     await superPage.locator('#admin-organization-select').selectOption(String(prepared.organization_id));
  42  |     const superCard = superPage.locator(`[data-organization-id="${prepared.organization_id}"]`);
  43  |     await capturePathViewports(superPage, dir, 'superadmin-program', [
  44  |       { name: 'program', locator: superCard.locator('select[name="program_definition_id"]') },
  45  |       { name: 'connect', locator: superCard.locator('form[data-action="connect-assessment-program"]').getByRole('button', { name: 'Подключить' }) },
  46  |     ]);
  47  |     await superPage.close();
  48  |     await context.addCookies([{ name: prepared.cookie_name, value: prepared.session, url: base }]);
  49  |     const page = await context.newPage();
  50  |     const url = base + `/users/admin/organizations/${prepared.organization_id}/assessment-assignments`;
  51  |     let requests = 0;
  52  |     page.on('request', (request) => { if (request.url() === url && request.method() === 'POST') requests += 1; });
  53  |     await page.goto(base);
  54  |     await expect(page.locator('#admin-organizations-panel')).toBeVisible();
  55  |     const card = page.locator(`[data-organization-id="${prepared.organization_id}"]`);
  56  |     const people = card.getByRole('button', { name: 'Организация и участники', exact: true });
  57  |     const emails = Object.values(prepared.member_emails);
  58  |     const select = async (email) => {
  59  |       await people.click();
  60  |       for (const checkbox of await card.locator('input[name="invitation_email"]').all()) await checkbox.uncheck();
  61  |       await card.locator(`input[name="invitation_email"][value="${email}"]`).check();
  62  |     };
  63  |     const assign = card.getByRole('button', { name: 'Назначить оценку', exact: true });
  64  |     await select(emails[0]);
  65  |     const response = page.waitForResponse((r) => r.url() === url && r.request().method() === 'POST');
  66  |     await assign.dblclick();
  67  |     expect((await response).status()).toBe(200);
  68  |     await expect(card.locator('[data-operation-status]').first()).toContainText('Назначена: 1');
  69  |     const afterDouble = inputs('readback');
  70  |     expect(afterDouble.assignments).toHaveLength(1);
  71  |     expect(afterDouble.bindings).toHaveLength(1);
  72  |     expect(afterDouble.cycles).toBe(0);
  73  |     events.push({ phase: 'double_click', actual_post_requests: requests, sql: afterDouble });
  74  |     expect(requests).toBe(1); // Actual UI in-flight guard, in addition to server concurrency tests.
  75  | 
  76  |     await select(emails[1]);
  77  |     let committed;
  78  |     await page.route(url, async (route) => {
  79  |       const real = await route.fetch(); // REAL request commits in PostgreSQL.
  80  |       committed = { status: real.status(), items: (await real.json()).items };
  81  |       await route.abort('failed'); // Lose delivery only, never fulfill a fake success.
  82  |     }, { times: 1 });
  83  |     await assign.click();
  84  |     await expect.poll(() => committed?.status).toBe(200);
  85  |     await expect(card.locator('[data-operation-status]').first()).toHaveAttribute('data-tone', 'error');
  86  |     const afterLost = inputs('readback');
  87  |     expect(afterLost.assignments).toHaveLength(2);
  88  |     expect(afterLost.bindings).toHaveLength(2);
  89  |     expect(afterLost.cycles).toBe(0);
  90  |     events.push({ phase: 'committed_response_aborted', real_response: committed, sql: afterLost });
  91  | 
  92  |     await page.reload();
  93  |     await expect(card).toBeVisible();
  94  |     await select(emails[1]);
  95  |     await assign.click();
  96  |     await expect(card.locator('[data-operation-status]').first()).toContainText('Уже была назначена: 1');
  97  |     for (let i = 0; i < 2; i += 1) {
  98  |       const read = await page.request.get(base + '/users/admin/organizations');
  99  |       expect(read.status()).toBe(200);
  100 |     }
  101 |     const final = inputs('readback');
  102 |     expect(final).toEqual(afterLost);
  103 |     events.push({ phase: 'reload_repeat_readback', sql: final });
  104 |     await page.screenshot({ path: path.join(dir, 'assignment-readback.png'), fullPage: true });
  105 |   } finally {
  106 |     // Preserve primary diagnostics BEFORE deleting only this owned DB.
  107 |     fs.writeFileSync(path.join(dir, 'events.json'), JSON.stringify(events, null, 2) + '\n');
  108 |     await context?.close();
  109 |     if (server && server.exitCode === null) {
  110 |       const ended = new Promise((resolve) => server.once('exit', resolve));
  111 |       server.kill('SIGTERM');
  112 |       await Promise.race([ended, new Promise((resolve) => setTimeout(resolve, 5000))]);
  113 |       if (server.exitCode === null) { server.kill('SIGKILL'); await ended; }
  114 |     }
  115 |     cli('destroy');
  116 |   }
  117 | });
  118 | 
```