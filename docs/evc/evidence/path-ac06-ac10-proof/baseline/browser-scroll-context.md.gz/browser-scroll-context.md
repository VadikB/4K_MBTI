# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: path-admin-contract.spec.mjs >> AC09 actual HTTP+PostgreSQL: double click, committed lost response, reload and repeat
- Location: tests/browser/path-admin-contract.spec.mjs:8:1

# Error details

```
Error: expect(locator).toBeInViewport() failed

Locator:  locator('[data-organization-id="1"]').locator('select[name="program_definition_id"]')
Expected: in viewport
Received: viewport ratio 0
Timeout:  5000ms

Call log:
  - Expect "toBeInViewport" locator('[data-organization-id="1"]').locator('select[name="program_definition_id"]') with timeout 5000ms
  - waiting for locator('[data-organization-id="1"]').locator('select[name="program_definition_id"]')
    14 × locator resolved to <select required="" name="program_definition_id">…</select>
       - unexpected value "viewport ratio 0"

```

```yaml
- combobox "Программа оценки":
  - option "Выберите опубликованную версию"
  - option "Synthetic test program · test.1" [selected]
```

# Test source

```ts
  1  | // Read-only presentation evidence. No request, start, answer or generation here.
  2  | import { expect } from '@playwright/test';
  3  | import fs from 'node:fs';
  4  | import path from 'node:path';
  5  | 
  6  | export async function capturePathViewports(page, directory, phase, controls) {
  7  |   const original = page.viewportSize();
  8  |   const records = [];
  9  |   const receipt = path.join(directory, `${phase}-viewports.json`);
  10 |   try {
  11 |     for (const width of [1440, 320, 390, 768]) {
  12 |       await page.setViewportSize({ width, height: 1000 });
  13 |       const record = { width, height: 1000, controls: [] };
  14 |       records.push(record);
  15 |       for (const { name, locator } of controls) {
  16 |         await expect(locator).toBeVisible();
  17 |         await locator.evaluate((el) => el.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' }));
> 18 |         await expect(locator).toBeInViewport();
     |                               ^ Error: expect(locator).toBeInViewport() failed
  19 |         const box = await locator.boundingBox();
  20 |         record.controls.push({ name, box, enabled: await locator.isEnabled() });
  21 |         fs.writeFileSync(receipt, JSON.stringify(records, null, 2) + '\n');
  22 |         expect(box.x, `${phase}/${name}/${width}: left`).toBeGreaterThanOrEqual(-1);
  23 |         expect(box.x + box.width, `${phase}/${name}/${width}: right`).toBeLessThanOrEqual(width + 1);
  24 |       }
  25 |       record.document = await page.evaluate(() => ({
  26 |         viewport: innerWidth, scrollWidth: document.documentElement.scrollWidth,
  27 |         visibleTextLength: document.body.innerText.length,
  28 |       }));
  29 |       record.screenshot = `${phase}-${width}.png`;
  30 |       fs.writeFileSync(receipt, JSON.stringify(records, null, 2) + '\n');
  31 |       await page.screenshot({ path: path.join(directory, record.screenshot), fullPage: true });
  32 |       expect(record.document.scrollWidth, `${phase}/${width}: document overflow`).toBeLessThanOrEqual(width + 1);
  33 |     }
  34 |   } finally {
  35 |     if (original) await page.setViewportSize(original);
  36 |   }
  37 |   return records;
  38 | }
  39 | 
```