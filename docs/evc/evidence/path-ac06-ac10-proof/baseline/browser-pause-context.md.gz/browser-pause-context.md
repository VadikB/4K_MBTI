# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: path29-participant.spec.mjs >> PATH29 owned backend: invitation → scoped chat → durable preparation → explicit first case
- Location: tests/browser/path29-participant.spec.mjs:19:1

# Error details

```
Error: expect(locator).toBeInViewport() failed

Locator:  locator('#interview-pause-button')
Expected: in viewport
Received: viewport ratio 0
Timeout:  5000ms

Call log:
  - Expect "toBeInViewport" locator('#interview-pause-button') with timeout 5000ms
  - waiting for locator('#interview-pause-button')
    14 × locator resolved to <button type="button" id="interview-pause-button" class="ghost-button interview-finish-button">Пауза</button>
       - unexpected value "viewport ratio 0"

```

```yaml
- button "Пауза"
```

# Test source

```ts
  1  | // Read-only presentation evidence. No request, start, answer or generation here.
  2  | import { expect } from '@playwright/test';
  3  | import fs from 'node:fs';
  4  | import path from 'node:path';
  5  | 
  6  | export async function capturePathViewports(page, directory, phase, controls) {
  7  |   const original = page.viewportSize();
  8  |   const records = [];
  9  |   const receipt = path.join(directory, `${phase}-viewports.json`);
  10 |   try {
  11 |     for (const width of [1440, 320, 390, 768]) {
  12 |       await page.setViewportSize({ width, height: 1000 });
  13 |       const record = { width, height: 1000, controls: [] };
  14 |       records.push(record);
  15 |       for (const { name, locator } of controls) {
  16 |         await expect(locator).toBeVisible();
  17 |         await locator.scrollIntoViewIfNeeded();
> 18 |         const box = await locator.boundingBox();
     |                               ^ Error: expect(locator).toBeInViewport() failed
  19 |         record.controls.push({ name, box, enabled: await locator.isEnabled() });
  20 |         fs.writeFileSync(receipt, JSON.stringify(records, null, 2) + '\n');
  21 |         await expect(locator).toBeInViewport();
  22 |         expect(box.x, `${phase}/${name}/${width}: left`).toBeGreaterThanOrEqual(-1);
  23 |         expect(box.x + box.width, `${phase}/${name}/${width}: right`).toBeLessThanOrEqual(width + 1);
  24 |       }
  25 |       record.document = await page.evaluate(() => ({
  26 |         viewport: innerWidth, scrollWidth: document.documentElement.scrollWidth,
  27 |         visibleTextLength: document.body.innerText.length,
  28 |       }));
  29 |       record.screenshot = `${phase}-${width}.png`;
  30 |       fs.writeFileSync(receipt, JSON.stringify(records, null, 2) + '\n');
  31 |       await page.screenshot({ path: path.join(directory, record.screenshot), fullPage: true });
  32 |       expect(record.document.scrollWidth, `${phase}/${width}: document overflow`).toBeLessThanOrEqual(width + 1);
  33 |     }
  34 |   } catch (error) {
  35 |     const failed = records.at(-1);
  36 |     if (failed) {
  37 |       failed.error = 'VIEWPORT_ASSERTION_FAILED';
  38 |       fs.writeFileSync(receipt, JSON.stringify(records, null, 2) + '\n');
  39 |       await page.screenshot({ path: path.join(directory, `${phase}-failed-${failed.width}.png`), fullPage: true });
  40 |     }
  41 |     throw error;
  42 |   } finally {
  43 |     if (original) await page.setViewportSize(original);
  44 |   }
  45 |   return records;
  46 | }
  47 | 
```