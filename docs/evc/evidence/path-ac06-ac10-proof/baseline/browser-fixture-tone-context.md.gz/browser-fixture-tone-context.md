# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: path-admin-contract.spec.mjs >> AC09 actual HTTP+PostgreSQL: double click, committed lost response, reload and repeat
- Location: tests/browser/path-admin-contract.spec.mjs:7:1

# Error details

```
Error: expect(locator).toHaveClass(expected) failed

Locator: locator('[data-organization-id="1"]').locator('[data-operation-status]').first()
Expected pattern: /error/
Received string:  "admin-organizations-status"
Timeout: 5000ms

Call log:
  - Expect "toHaveClass" locator('[data-organization-id="1"]').locator('[data-operation-status]').first() with timeout 5000ms
  - waiting for locator('[data-organization-id="1"]').locator('[data-operation-status]').first()
    14 × locator resolved to <p role="status" tabindex="-1" data-tone="error" aria-live="polite" data-operation-status="" class="admin-organizations-status">…</p>
       - unexpected value "admin-organizations-status"

```

```yaml
- status:
  - text: Failed to fetch
  - button "Открыть данные оценки «ac0610-c72c6e5c807f»"
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | import { spawn, spawnSync } from 'node:child_process';
  3   | import fs from 'node:fs';
  4   | import path from 'node:path';
  5   | import { randomUUID } from 'node:crypto';
  6   | 
  7   | test('AC09 actual HTTP+PostgreSQL: double click, committed lost response, reload and repeat', async ({ browser }) => {
  8   |   test.setTimeout(150000);
  9   |   if (!process.env.STAND_ADMIN_URL) throw new Error('Explicit isolated STAND_ADMIN_URL required');
  10  |   const python = process.env.BROWSER_PYTHON || path.join(process.cwd(), '.venv/bin/python');
  11  |   const dir = path.join(process.env.PATH_ADMIN_BROWSER_EVIDENCE || '.test-stand/path-admin-contract', randomUUID());
  12  |   fs.mkdirSync(dir, { recursive: true });
  13  |   const statePath = path.resolve(dir, 'state.json'), base = 'http://127.0.0.1:18872';
  14  |   const cli = (action) => {
  15  |     const result = spawnSync(python, ['scripts/test_stand.py', action, '--state', statePath, '--port', '18872'], { encoding: 'utf8', timeout: 180000 });
  16  |     fs.appendFileSync(path.join(dir, 'stand.log'), result.stdout + result.stderr);
  17  |     if (result.status !== 0) throw new Error('stand ' + action + ' failed; see stand.log');
  18  |   };
  19  |   const inputs = (action) => {
  20  |     const result = spawnSync(python, ['tests/path_admin_browser_inputs.py', action, '--state', statePath], { encoding: 'utf8', timeout: 60000 });
  21  |     if (result.status !== 0) throw new Error(result.stderr);
  22  |     return JSON.parse(result.stdout.trim().split('\n').at(-1));
  23  |   };
  24  |   let server, context;
  25  |   const events = [];
  26  |   cli('create');
  27  |   try {
  28  |     cli('bootstrap');
  29  |     cli('seed');
  30  |     const prepared = inputs('prepare');
  31  |     const fd = fs.openSync(path.join(dir, 'server.log'), 'a');
  32  |     server = spawn(python, ['scripts/test_stand.py', 'serve', '--state', statePath], { stdio: ['ignore', fd, fd] });
  33  |     fs.closeSync(fd);
  34  |     await expect.poll(async () => { try { return (await fetch(base + '/health/ready')).status; } catch { return 0; } }, { timeout: 30000 }).toBe(200);
  35  |     context = await browser.newContext();
  36  |     await context.addCookies([{ name: prepared.cookie_name, value: prepared.session, url: base }]);
  37  |     const page = await context.newPage();
  38  |     const url = base + `/users/admin/organizations/${prepared.organization_id}/assessment-assignments`;
  39  |     let requests = 0;
  40  |     page.on('request', (request) => { if (request.url() === url && request.method() === 'POST') requests += 1; });
  41  |     await page.goto(base);
  42  |     await expect(page.locator('#admin-organizations-panel')).toBeVisible();
  43  |     const card = page.locator(`[data-organization-id="${prepared.organization_id}"]`);
  44  |     const people = card.getByRole('button', { name: 'Организация и участники', exact: true });
  45  |     const emails = Object.values(prepared.member_emails);
  46  |     const select = async (email) => {
  47  |       await people.click();
  48  |       for (const checkbox of await card.locator('input[name="invitation_email"]').all()) await checkbox.uncheck();
  49  |       await card.locator(`input[name="invitation_email"][value="${email}"]`).check();
  50  |     };
  51  |     const assign = card.getByRole('button', { name: 'Назначить оценку', exact: true });
  52  |     await select(emails[0]);
  53  |     const response = page.waitForResponse((r) => r.url() === url && r.request().method() === 'POST');
  54  |     await assign.dblclick();
  55  |     expect((await response).status()).toBe(200);
  56  |     await expect(card.locator('[data-operation-status]').first()).toContainText('Назначена: 1');
  57  |     const afterDouble = inputs('readback');
  58  |     expect(afterDouble.assignments).toHaveLength(1);
  59  |     expect(afterDouble.bindings).toHaveLength(1);
  60  |     expect(afterDouble.cycles).toBe(0);
  61  |     events.push({ phase: 'double_click', actual_post_requests: requests, sql: afterDouble });
  62  |     expect(requests).toBe(1); // Actual UI in-flight guard, in addition to server concurrency tests.
  63  | 
  64  |     await select(emails[1]);
  65  |     let committed;
  66  |     await page.route(url, async (route) => {
  67  |       const real = await route.fetch(); // REAL request commits in PostgreSQL.
  68  |       committed = { status: real.status(), items: (await real.json()).items };
  69  |       await route.abort('failed'); // Lose delivery only, never fulfill a fake success.
  70  |     }, { times: 1 });
  71  |     await assign.click();
  72  |     await expect.poll(() => committed?.status).toBe(200);
> 73  |     await expect(card.locator('[data-operation-status]').first()).toHaveClass(/error/);
      |                                                                   ^ Error: expect(locator).toHaveClass(expected) failed
  74  |     const afterLost = inputs('readback');
  75  |     expect(afterLost.assignments).toHaveLength(2);
  76  |     expect(afterLost.bindings).toHaveLength(2);
  77  |     expect(afterLost.cycles).toBe(0);
  78  |     events.push({ phase: 'committed_response_aborted', real_response: committed, sql: afterLost });
  79  | 
  80  |     await page.reload();
  81  |     await expect(card).toBeVisible();
  82  |     await select(emails[1]);
  83  |     await assign.click();
  84  |     await expect(card.locator('[data-operation-status]').first()).toContainText('Уже была назначена: 1');
  85  |     for (let i = 0; i < 2; i += 1) {
  86  |       const read = await page.request.get(base + '/users/admin/organizations');
  87  |       expect(read.status()).toBe(200);
  88  |     }
  89  |     const final = inputs('readback');
  90  |     expect(final).toEqual(afterLost);
  91  |     events.push({ phase: 'reload_repeat_readback', sql: final });
  92  |     await page.screenshot({ path: path.join(dir, 'assignment-readback.png'), fullPage: true });
  93  |   } finally {
  94  |     // Preserve primary diagnostics BEFORE deleting only this owned DB.
  95  |     fs.writeFileSync(path.join(dir, 'events.json'), JSON.stringify(events, null, 2) + '\n');
  96  |     await context?.close();
  97  |     if (server && server.exitCode === null) {
  98  |       const ended = new Promise((resolve) => server.once('exit', resolve));
  99  |       server.kill('SIGTERM');
  100 |       await Promise.race([ended, new Promise((resolve) => setTimeout(resolve, 5000))]);
  101 |       if (server.exitCode === null) { server.kill('SIGKILL'); await ended; }
  102 |     }
  103 |     cli('destroy');
  104 |   }
  105 | });
  106 | 
```