# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth-r03.spec.mjs >> PROGRAM01 R10 finishes exact program connection while questionnaire refresh is pending
- Location: tests/browser/auth-r03.spec.mjs:445:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('[data-action="connect-assessment-program"]').locator('[data-operation-status]')
Expected substring: "Опубликованная версия программы подключена"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" locator('[data-action="connect-assessment-program"]').locator('[data-operation-status]') with timeout 5000ms
  - waiting for locator('[data-action="connect-assessment-program"]').locator('[data-operation-status]')

```

```yaml
- main:
  - text: 4К Ассистент
  - navigation "Разделы аккаунта":
    - button "Управление"
  - text: Admin
  - button "К сводке"
  - button "Выйти"
  - paragraph: Управление
  - heading "Организации" [level=2]
  - paragraph: Управление доменами и администраторами организаций.
  - paragraph: Новая организация
  - heading "Создать организацию" [level=3]
  - text: Название
  - textbox "Название":
    - /placeholder: Например, ACME
  - text: Код
  - textbox "Код":
    - /placeholder: acme
  - button "Создать"
  - paragraph: Рабочая область
  - heading "Управление организацией" [level=3]
  - text: Выберите организацию
  - combobox "Выберите организацию":
    - option "R10 Organization · r10" [selected]
  - heading "Ранее отвязанные аккаунты" [level=3]
  - paragraph: Ранее отвязанных аккаунтов нет.
  - article:
    - paragraph: r10
    - heading "R10 Organization" [level=3]
    - paragraph: Активна
    - text: 0 участников 0 отчетов
    - button "Подготовить кейсы всем"
    - button "Деактивировать"
    - text: Программа оценки
    - combobox "Программа оценки":
      - option "Выберите опубликованную версию"
      - option "Пилот 4К · 9 кейсов · 1.1" [selected]
    - button "Подключить"
    - paragraph:
      - text: "Подключено:"
      - strong: Пилот 4К · 9 кейсов · 1.1
    - paragraph: Профиль
    - heading "Сведения об организации" [level=4]
    - button "Сохранить карточку"
    - text: Название
    - textbox "Название": R10 Organization
    - text: Код
    - textbox "Код": r10
    - text: Год основания
    - spinbutton "Год основания"
    - text: Численность
    - spinbutton "Численность"
    - text: Отрасль
    - textbox "Отрасль":
      - /placeholder: Например, финтех
    - text: Сайт
    - textbox "Сайт":
      - /placeholder: https://company.ru
    - text: Штаб-квартира
    - textbox "Штаб-квартира":
      - /placeholder: Город, страна
    - text: Прочая существенная информация
    - textbox "Прочая существенная информация":
      - /placeholder: Структура, география, культура и другие важные сведения
    - heading "Домены" [level=4]
    - paragraph: Домены не заданы.
    - textbox "company.ru"
    - button "Добавить"
    - heading "Администраторы" [level=4]
    - paragraph: Администраторы не заданы.
    - textbox "admin@company.ru"
    - button "Добавить"
    - navigation "Разделы управления":
      - button "Организация и участники" [pressed]
      - button "Данные организации"
      - button "Анкета"
    - heading "Организация и участники" [level=4]
    - term: Выбранная оценка
    - definition: pilot-4k-9
    - term: Подключённая программа
    - definition: Пилот 4К · 9 кейсов · 1.1
    - paragraph: Назначение не запускает оценку.
    - region "Готовность назначения":
      - heading "Готовность назначения" [level=5]
      - term: Программа
      - definition: Пилот 4К · 9 кейсов · 1.1
      - term: Роль
      - definition: недоступна
      - term: Оценка
      - definition: pilot-4k-9
      - term: Анкета
      - definition: проверяем актуальность
      - alert:
        - strong: Назначение пока недоступно
        - list:
          - listitem: Проверяем сохранённую анкету. Дождитесь завершения чтения.
          - listitem: В подключённой программе нет доступной роли для назначения.
    - checkbox "Выбрать всех"
    - text: Выбрать всех
    - strong: 0 выбрано
    - paragraph: Участники не привязаны.
    - heading "Добавить участника" [level=4]
    - paragraph: Для добавления нужны email, ФИО и должность.
    - text: Email
    - textbox "Email":
      - /placeholder: user@company.ru
    - text: ФИО
    - textbox "ФИО":
      - /placeholder: Иван Иванов
    - text: Должность
    - textbox "Должность":
      - /placeholder: Руководитель отдела
    - button "Добавить"
    - button "Choose File"
    - text: "CSV: email, full_name, role_description, job_instructions"
    - button "Импорт"
  - text: Политика конфиденциальности Согласие на обработку персональных данных Версия 2.0.68 © 2026 LIDUM
```

# Test source

```ts
  393 |           if (readbackFailure === 'http503') return fulfillJson(route, { detail: 'Synthetic readback unavailable' }, 503);
  394 |           if (readbackFailure === 'network') return route.abort('connectionreset');
  395 |           if (readbackFailure === 'invalid-json') return route.fulfill({ status: 200, contentType: 'application/json', body: '{' });
  396 |           if (readbackFailure === 'null') return fulfillJson(route, { connection: null });
  397 |           return fulfillJson(route, { connection: { ...connection, program_definition_id: 999, program_name: 'Foreign program' } });
  398 |         }
  399 |         return fulfillJson(route, {}, 404);
  400 |       });
  401 |       await page.goto(base);
  402 |       await page.locator('#admin-open-organizations-button').click();
  403 |       const form = page.locator('[data-action="connect-assessment-program"]');
  404 |       const button = form.getByRole('button', { name: 'Подключить', exact: true });
  405 |       await form.locator('[name="program_definition_id"]').selectOption('11');
  406 |       await button.click();
  407 |       const status = form.locator('[data-operation-status]');
  408 |       try {
  409 |         await expect(status).toHaveAttribute('data-tone', 'error', { timeout: 22000 });
  410 |         await expect(status).not.toContainText('Выполняем действие');
  411 |         await expect(status).toContainText('Результат подключения не подтверждён');
  412 |         await expect(button).toBeEnabled();
  413 |         await expect(page.locator('[data-organization-id="3"]')).not.toContainText(/не подключена/i);
  414 |         await expect(form.locator('[data-program-connection-state]')).toContainText('пока не подтверждён');
  415 |         await expect(form).not.toContainText('Foreign program');
  416 |         await page.screenshot({ path: testInfo.outputPath('ac05-unknown.png') });
  417 |       } finally { releaseReadback(); }
  418 |       if (readbackFailure === 'http503' && !lostCommandResponse) {
  419 |         await page.locator('#admin-organizations-back-button').click();
  420 |         await page.locator('#admin-open-organizations-button').click();
  421 |         await expect(form.locator('[data-program-connection-state]')).toContainText('пока не подтверждён');
  422 |         for (const width of [1440, 320, 390, 768]) {
  423 |           await page.setViewportSize({ width, height: 1000 });
  424 |           await button.scrollIntoViewIfNeeded();
  425 |           await expect(button).toBeVisible();
  426 |           const box = await form.boundingBox();
  427 |           expect(box.x).toBeGreaterThanOrEqual(0);
  428 |           expect(box.x + box.width).toBeLessThanOrEqual(width + 1);
  429 |           await page.screenshot({ path: testInfo.outputPath(`ac05-unknown-${width}.png`) });
  430 |         }
  431 |       }
  432 |       await button.click();
  433 |       await expect(form.locator('[data-operation-status]')).toHaveAttribute('data-tone', 'success');
  434 |       await expect(form).toContainText('Подключено: Owned AC05 pilot · synthetic-v1');
  435 |       expect(operationIds).toHaveLength(2);
  436 |       expect(operationIds[1]).toBe(operationIds[0]);
  437 |       expect(new Set(operationIds).size).toBe(1);
  438 |       expect(getCount).toBe(2);
  439 |       await reloadSuperadminOrganizations(page);
  440 |       await expect(form).toContainText('Подключено: Owned AC05 pilot · synthetic-v1');
  441 |     });
  442 |   }
  443 | }
  444 | 
  445 | test('PROGRAM01 R10 finishes exact program connection while questionnaire refresh is pending', async ({ page }) => {
  446 |   const dashboard = { is_superadmin: true, metrics: [], insights: [], activity_series: [], competency_average: [] };
  447 |   const connection = {
  448 |     organization_id: 3, program_definition_id: 11, program_name: 'Пилот 4К · 9 кейсов',
  449 |     program_version: '1.1', assignment_ref: 'pilot-4k-9', roles: [], role_capabilities: [],
  450 |   };
  451 |   const organization = {
  452 |     id: 3, code: 'r10', name: 'R10 Organization', is_active: true, domains: [], admins: [],
  453 |     members_count: 0, reports_count: 0, members: [], assessment_program: null,
  454 |   };
  455 |   let releaseQuestionnaire;
  456 |   const questionnairePending = new Promise((resolve) => { releaseQuestionnaire = resolve; });
  457 |   let questionnaireRequests = 0;
  458 |   await page.route('**/users/**', async (route) => {
  459 |     const pathname = new URL(route.request().url()).pathname;
  460 |     if (pathname === '/users/session/restore') return fulfillJson(route, {
  461 |       authenticated: true, user: adminUser, is_admin: true, admin_dashboard: dashboard,
  462 |     });
  463 |     if (pathname === '/users/version') return fulfillJson(route, { version: 'r10-test' });
  464 |     if (pathname === '/users/admin/dashboard') return fulfillJson(route, dashboard);
  465 |     if (pathname === '/users/admin/organizations' && route.request().method() === 'GET') {
  466 |       return fulfillJson(route, {
  467 |         is_superadmin: true, items: [organization],
  468 |         assessment_programs: [{ id: 11, name: connection.program_name, version: connection.program_version }],
  469 |       });
  470 |     }
  471 |     if (pathname === '/users/admin/organizations/3/questionnaire') {
  472 |       questionnaireRequests += 1;
  473 |       await questionnairePending;
  474 |       return fulfillJson(route, { detail: 'synthetic questionnaire unavailable' }, 503);
  475 |     }
  476 |     if (pathname === '/users/admin/organizations/3/assessment-program' && route.request().method() === 'PUT') {
  477 |       return fulfillJson(route, { connection });
  478 |     }
  479 |     if (pathname === '/users/admin/organizations/3/assessment-program' && route.request().method() === 'GET') {
  480 |       return fulfillJson(route, { connection });
  481 |     }
  482 |     return fulfillJson(route, {}, 404);
  483 |   });
  484 |   await page.goto(base);
  485 |   await page.locator('#admin-open-organizations-button').click();
  486 |   const form = page.locator('[data-action="connect-assessment-program"]');
  487 |   await form.locator('[name="program_definition_id"]').selectOption('11');
  488 |   await form.getByRole('button', { name: 'Подключить' }).click();
  489 |   await expect(form).toContainText('Подключено: Пилот 4К · 9 кейсов · 1.1');
  490 |   await expect(form.locator('[data-operation-status]')).toContainText('Опубликованная версия программы подключена');
  491 |   expect(questionnaireRequests).toBeGreaterThanOrEqual(1);
  492 |   releaseQuestionnaire();
> 493 |   await expect(form.locator('[data-operation-status]')).toContainText('Опубликованная версия программы подключена');
      |                                                         ^ Error: expect(locator).toContainText(expected) failed
  494 | });
  495 | 
  496 | test('PROGRAM01 R10 shows a terminal error when exact readback is null', async ({ page }) => {
  497 |   const dashboard = { is_superadmin: true, metrics: [], insights: [], activity_series: [], competency_average: [] };
  498 |   const organization = {
  499 |     id: 3, code: 'r10-null', name: 'R10 Null Organization', is_active: true, domains: [], admins: [],
  500 |     members_count: 0, reports_count: 0, members: [], assessment_program: null,
  501 |   };
  502 |   const operationIds = [];
  503 |   await page.route('**/users/**', (route) => {
  504 |     const pathname = new URL(route.request().url()).pathname;
  505 |     if (pathname === '/users/session/restore') return fulfillJson(route, {
  506 |       authenticated: true, user: adminUser, is_admin: true, admin_dashboard: dashboard,
  507 |     });
  508 |     if (pathname === '/users/version') return fulfillJson(route, { version: 'r10-test' });
  509 |     if (pathname === '/users/admin/dashboard') return fulfillJson(route, dashboard);
  510 |     if (pathname === '/users/admin/organizations' && route.request().method() === 'GET') return fulfillJson(route, {
  511 |       is_superadmin: true, items: [organization],
  512 |       assessment_programs: [{ id: 11, name: 'Пилот 4К · 9 кейсов', version: '1.1' }],
  513 |     });
  514 |     if (pathname === '/users/admin/organizations/3/questionnaire') return fulfillJson(route, { items: [] });
  515 |     if (pathname === '/users/admin/organizations/3/assessment-program' && route.request().method() === 'PUT') {
  516 |       operationIds.push(route.request().postDataJSON().operation_id);
  517 |       return fulfillJson(route, { connection: { organization_id: 3, program_definition_id: 11 } });
  518 |     }
  519 |     if (pathname === '/users/admin/organizations/3/assessment-program' && route.request().method() === 'GET') {
  520 |       return fulfillJson(route, { connection: null });
  521 |     }
  522 |     return fulfillJson(route, {}, 404);
  523 |   });
  524 |   await page.goto(base);
  525 |   await page.locator('#admin-open-organizations-button').click();
  526 |   const form = page.locator('[data-action="connect-assessment-program"]');
  527 |   await form.locator('[name="program_definition_id"]').selectOption('11');
  528 |   await form.getByRole('button', { name: 'Подключить' }).click();
  529 |   await expect(form.locator('[data-operation-status]')).toContainText('повторное чтение не подтвердило');
  530 |   await expect(form.locator('[data-operation-status]')).not.toContainText('Выполняем действие');
  531 |   await expect(form.getByRole('button', { name: 'Подключить' })).toBeEnabled();
  532 |   await form.getByRole('button', { name: 'Подключить' }).click();
  533 |   await expect.poll(() => operationIds.length).toBe(2);
  534 |   expect(operationIds[1]).toBe(operationIds[0]);
  535 | });
  536 | 
  537 | for (const lostCommandResponse of [false, true]) {
  538 |   test(`PATH-START AC05 rejects a foreign organization readback after ${lostCommandResponse ? 'lost' : 'confirmed'} command`, async ({ page }) => {
  539 |     const dashboard = { is_superadmin: true, metrics: [], insights: [], activity_series: [], competency_average: [] };
  540 |     const organization = { id: 3, code: 'ac05-foreign', name: 'Owned synthetic organization',
  541 |       is_active: true, domains: [], admins: [], members_count: 0, reports_count: 0,
  542 |       members: [], assessment_program: null };
  543 |     const connection = { organization_id: 3, program_definition_id: 11,
  544 |       program_name: 'Owned pilot', program_version: '1.1', assignment_ref: 'pilot-4k-9',
  545 |       roles: [], role_capabilities: [] };
  546 |     const operationIds = [];
  547 |     await page.route('**/users/**', (route) => {
  548 |       const pathname = new URL(route.request().url()).pathname;
  549 |       if (pathname === '/users/session/restore') return fulfillJson(route, {
  550 |         authenticated: true, user: adminUser, is_admin: true, admin_dashboard: dashboard,
  551 |       });
  552 |       if (pathname === '/users/version') return fulfillJson(route, { version: 'ac05-test' });
  553 |       if (pathname === '/users/admin/dashboard') return fulfillJson(route, dashboard);
  554 |       if (pathname === '/users/admin/organizations' && route.request().method() === 'GET') {
  555 |         return fulfillJson(route, { is_superadmin: true, items: [organization],
  556 |           assessment_programs: [{ id: 11, name: connection.program_name, version: connection.program_version }] });
  557 |       }
  558 |       if (pathname === '/users/admin/organizations/3/questionnaire') return fulfillJson(route, { items: [] });
  559 |       if (pathname === '/users/admin/organizations/3/assessment-program') {
  560 |         if (route.request().method() === 'PUT') {
  561 |           operationIds.push(route.request().postDataJSON().operation_id);
  562 |           return lostCommandResponse ? route.abort('connectionreset') : fulfillJson(route, { connection });
  563 |         }
  564 |         return fulfillJson(route, { connection: { ...connection, organization_id: 999,
  565 |           program_name: 'Foreign organization pilot' } });
  566 |       }
  567 |       return fulfillJson(route, {}, 404);
  568 |     });
  569 |     await page.goto(base);
  570 |     await page.locator('#admin-open-organizations-button').click();
  571 |     const form = page.locator('[data-action="connect-assessment-program"]');
  572 |     await form.locator('[name="program_definition_id"]').selectOption('11');
  573 |     await form.getByRole('button', { name: 'Подключить' }).click();
  574 |     const status = form.locator('[data-operation-status]');
  575 |     await expect(status).toHaveAttribute('data-tone', 'error');
  576 |     await expect(form).not.toContainText('Foreign organization pilot');
  577 |     await expect(form.getByRole('button', { name: 'Подключить' })).toBeEnabled();
  578 |     await form.getByRole('button', { name: 'Подключить' }).click();
  579 |     await expect.poll(() => operationIds.length).toBe(2);
  580 |     expect(operationIds[1]).toBe(operationIds[0]);
  581 |     await expect(status).toHaveAttribute('data-tone', 'error');
  582 |   });
  583 | }
  584 | 
  585 | test('PROGRAM01 R10 confirms a committed connection after the PUT response is lost', async ({ page }) => {
  586 |   const dashboard = { is_superadmin: true, metrics: [], insights: [], activity_series: [], competency_average: [] };
  587 |   const connection = {
  588 |     organization_id: 3, program_definition_id: 11, program_name: 'Пилот 4К · 9 кейсов',
  589 |     program_version: '1.1', assignment_ref: 'pilot-4k-9', roles: [], role_capabilities: [],
  590 |   };
  591 |   const operationIds = [];
  592 |   let serverConnected = false;
  593 |   await page.route('**/users/**', (route) => {
```